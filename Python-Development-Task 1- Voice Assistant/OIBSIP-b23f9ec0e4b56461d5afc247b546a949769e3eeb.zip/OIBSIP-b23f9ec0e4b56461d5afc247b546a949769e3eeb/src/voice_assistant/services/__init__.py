"""Services package containing weather, email, reminders, and knowledge subsystems."""

from voice_assistant.services.email import EmailMessageData, EmailResult, EmailService
from voice_assistant.services.knowledge import KnowledgeAnswer, KnowledgeService
from voice_assistant.services.reminders import Reminder, ReminderScheduler
from voice_assistant.services.weather import WeatherData, WeatherService

__all__ = [
    "WeatherData",
    "WeatherService",
    "Reminder",
    "ReminderScheduler",
    "EmailMessageData",
    "EmailResult",
    "EmailService",
    "KnowledgeAnswer",
    "KnowledgeService",
]
