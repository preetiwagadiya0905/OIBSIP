"""Domain models for scheduled reminders."""

import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone

from voice_assistant.config.constants import ReminderStatus


@dataclass
class Reminder:
    """Represents a scheduled reminder task."""
    duration_seconds: int
    message: str
    id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    status: ReminderStatus = ReminderStatus.SCHEDULED
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    completed_at: datetime | None = None

    @property
    def human_duration(self) -> str:
        """Format duration into human-friendly string."""
        total = self.duration_seconds
        if total < 60:
            return f"{total} seconds" if total != 1 else "1 second"
        minutes = total // 60
        remaining_seconds = total % 60
        if total < 3600:
            if remaining_seconds:
                return f"{minutes} minutes and {remaining_seconds} seconds"
            return f"{minutes} minutes" if minutes != 1 else "1 minute"
        hours = total // 3600
        remaining_minutes = (total % 3600) // 60
        if remaining_minutes:
            return f"{hours} hours and {remaining_minutes} minutes"
        return f"{hours} hours" if hours != 1 else "1 hour"
