"""Domain models for email messages and transmission results."""

from dataclasses import dataclass

from voice_assistant.security.validators import validate_email_address


@dataclass(frozen=True)
class EmailMessageData:
    """Domain model representing a validated email to be dispatched."""
    recipient: str
    subject: str
    body: str
    sender: str | None = None

    def validate(self) -> None:
        """Validate email fields."""
        validate_email_address(self.recipient)
        if not self.subject or not self.subject.strip():
            raise ValueError("Email subject cannot be empty.")
        if not self.body or not self.body.strip():
            raise ValueError("Email body cannot be empty.")


@dataclass(frozen=True)
class EmailResult:
    """Represents the outcome of an email dispatch operation."""
    success: bool
    recipient: str
    subject: str
    error_message: str | None = None
