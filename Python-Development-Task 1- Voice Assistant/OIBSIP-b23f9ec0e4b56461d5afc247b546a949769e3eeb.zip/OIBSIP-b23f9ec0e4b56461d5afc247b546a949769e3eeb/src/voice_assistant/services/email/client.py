"""SMTP client implementation using standard Python email.message.EmailMessage."""

import smtplib
from email.message import EmailMessage

from voice_assistant.config.settings import SMTPSettings
from voice_assistant.errors.exceptions import EmailServiceError
from voice_assistant.observability.logging import get_logger
from voice_assistant.services.email.models import EmailMessageData, EmailResult

logger = get_logger(__name__)


class SMTPEmailClient:
    """Production SMTP client for sending emails securely."""

    def __init__(self, settings: SMTPSettings):
        self.settings = settings

    def send(self, data: EmailMessageData) -> EmailResult:
        """Construct and send an email via SMTP server with TLS/SSL."""
        if not self.settings.is_configured:
            raise EmailServiceError(
                "SMTP is not configured. Please provide SMTP_HOST, SMTP_USERNAME, and SMTP_PASSWORD in .env"
            )

        data.validate()

        msg = EmailMessage()
        from_address = data.sender or self.settings.email_from or self.settings.username
        msg["From"] = from_address
        msg["To"] = data.recipient
        msg["Subject"] = data.subject
        msg.set_content(data.body)

        try:
            logger.info(f"Connecting to SMTP server {self.settings.host}:{self.settings.port}...")
            if self.settings.port == 465:
                # SSL direct connection
                server = smtplib.SMTP_SSL(
                    self.settings.host,
                    self.settings.port,
                    timeout=self.settings.timeout,
                )
            else:
                # Plain or STARTTLS connection
                server = smtplib.SMTP(
                    self.settings.host,
                    self.settings.port,
                    timeout=self.settings.timeout,
                )
                if self.settings.use_tls:
                    logger.debug("Upgrading SMTP connection to TLS...")
                    server.starttls()

            with server:
                logger.debug(f"Authenticating SMTP user: {self.settings.username}")
                server.login(self.settings.username, self.settings.password)
                logger.info(f"Dispatching email to {data.recipient}...")
                server.send_message(msg)

            logger.info(f"Email successfully dispatched to {data.recipient}")
            return EmailResult(success=True, recipient=data.recipient, subject=data.subject)

        except smtplib.SMTPAuthenticationError as e:
            logger.error("SMTP authentication failure.")
            raise EmailServiceError(
                "SMTP authentication failed. Please verify your username and password."
            ) from e
        except smtplib.SMTPConnectError as e:
            logger.error(f"Failed to connect to SMTP server: {e}")
            raise EmailServiceError("Could not connect to SMTP email server.") from e
        except smtplib.SMTPRecipientsRefused as e:
            logger.error(f"Recipient address rejected by SMTP server: {e}")
            raise EmailServiceError(f"Recipient address '{data.recipient}' was rejected by the server.") from e
        except (smtplib.SMTPException, TimeoutError, OSError) as e:
            logger.error(f"SMTP error during email transmission: {e}")
            raise EmailServiceError(f"Email delivery failed: {e}") from e
