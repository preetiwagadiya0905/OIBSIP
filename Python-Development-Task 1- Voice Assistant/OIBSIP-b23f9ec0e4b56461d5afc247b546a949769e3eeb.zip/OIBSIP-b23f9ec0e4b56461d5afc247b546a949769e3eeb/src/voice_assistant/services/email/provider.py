"""Email provider interfaces and implementations."""

from typing import Protocol

from voice_assistant.errors.exceptions import EmailServiceError
from voice_assistant.observability.logging import get_logger
from voice_assistant.services.email.client import SMTPEmailClient
from voice_assistant.services.email.models import EmailMessageData, EmailResult

logger = get_logger(__name__)


class EmailProvider(Protocol):
    """Protocol for sending emails."""

    def send_email(self, message: EmailMessageData) -> EmailResult:
        """Send the specified email message."""
        ...


class SMTPEmailProvider:
    """Production provider using real SMTP client."""

    def __init__(self, client: SMTPEmailClient):
        self.client = client

    def send_email(self, message: EmailMessageData) -> EmailResult:
        return self.client.send(message)


class MockEmailProvider:
    """Mock email provider for tests and test-run mode."""

    def __init__(self, should_fail: bool = False, fail_reason: str = "Simulated SMTP failure"):
        self.sent_emails: list[EmailMessageData] = []
        self.should_fail = should_fail
        self.fail_reason = fail_reason

    def send_email(self, message: EmailMessageData) -> EmailResult:
        message.validate()
        if self.should_fail:
            raise EmailServiceError(self.fail_reason)
        self.sent_emails.append(message)
        logger.info(f"MockEmailProvider recorded email to {message.recipient}: '{message.subject}'")
        return EmailResult(success=True, recipient=message.recipient, subject=message.subject)


class EmailService:
    """Application service for email operations."""

    def __init__(self, provider: EmailProvider):
        self.provider = provider

    def send(self, recipient: str, subject: str, body: str, sender: str | None = None) -> EmailResult:
        """Validate and dispatch email message."""
        msg = EmailMessageData(
            recipient=recipient.strip(),
            subject=subject.strip(),
            body=body.strip(),
            sender=sender,
        )
        return self.provider.send_email(msg)
