"""Email service package."""

from voice_assistant.services.email.client import SMTPEmailClient
from voice_assistant.services.email.models import EmailMessageData, EmailResult
from voice_assistant.services.email.provider import (
    EmailProvider,
    EmailService,
    MockEmailProvider,
    SMTPEmailProvider,
)

__all__ = [
    "EmailMessageData",
    "EmailResult",
    "SMTPEmailClient",
    "EmailProvider",
    "SMTPEmailProvider",
    "MockEmailProvider",
    "EmailService",
]
