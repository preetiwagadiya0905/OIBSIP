"""Knowledge service package."""

from voice_assistant.services.knowledge.client import (
    DuckDuckGoKnowledgeClient,
    WikipediaKnowledgeClient,
)
from voice_assistant.services.knowledge.models import KnowledgeAnswer
from voice_assistant.services.knowledge.provider import (
    CompositeKnowledgeProvider,
    KnowledgeProvider,
    KnowledgeService,
    LocalCuratedKnowledgeProvider,
    MockKnowledgeProvider,
)

__all__ = [
    "KnowledgeAnswer",
    "WikipediaKnowledgeClient",
    "DuckDuckGoKnowledgeClient",
    "KnowledgeProvider",
    "LocalCuratedKnowledgeProvider",
    "CompositeKnowledgeProvider",
    "MockKnowledgeProvider",
    "KnowledgeService",
]
