"""Geocoding service for resolving location names to geographic coordinates."""

from dataclasses import dataclass

import requests

from voice_assistant.errors.exceptions import WeatherServiceError
from voice_assistant.observability.logging import get_logger

logger = get_logger(__name__)


@dataclass(frozen=True)
class GeoCoordinates:
    latitude: float
    longitude: float
    name: str
    country: str | None = None
    state: str | None = None


class OpenWeatherMapGeocoder:
    """Uses OpenWeatherMap Direct Geocoding API to resolve coordinates."""

    GEO_URL = "http://api.openweathermap.org/geo/1.0/direct"

    def __init__(self, api_key: str, timeout: float = 8.0):
        self.api_key = api_key
        self.timeout = timeout

    def geocode(self, location_query: str) -> GeoCoordinates:
        """Resolve a city or place query to geographical coordinates."""
        if not self.api_key:
            raise WeatherServiceError("OpenWeatherMap API key is not configured.")

        clean_query = location_query.strip()
        if not clean_query:
            raise WeatherServiceError("Location query cannot be empty.")

        params = {
            "q": clean_query,
            "limit": 1,
            "appid": self.api_key,
        }

        try:
            logger.debug(f"Geocoding location: '{clean_query}'")
            response = requests.get(self.GEO_URL, params=params, timeout=self.timeout)

            if response.status_code == 401:
                raise WeatherServiceError("Invalid OpenWeatherMap API key.")
            if response.status_code == 429:
                raise WeatherServiceError("OpenWeatherMap API rate limit exceeded.")
            if response.status_code != 200:
                raise WeatherServiceError(
                    f"Geocoding service error (HTTP {response.status_code})"
                )

            data = response.json()
            if not data or not isinstance(data, list) or len(data) == 0:
                raise WeatherServiceError(f"I couldn't find coordinates for '{clean_query}'.")

            first = data[0]
            lat = float(first.get("lat"))
            lon = float(first.get("lon"))
            name = first.get("name", clean_query)
            country = first.get("country")
            state = first.get("state")

            logger.info(f"Geocoded '{clean_query}' -> {name}, {country} ({lat:.4f}, {lon:.4f})")
            return GeoCoordinates(
                latitude=lat,
                longitude=lon,
                name=name,
                country=country,
                state=state,
            )

        except requests.Timeout as e:
            logger.error(f"Geocoding network timeout for query '{clean_query}': {e}")
            raise WeatherServiceError("Weather geocoding request timed out. Please try again.") from e
        except requests.RequestException as e:
            logger.error(f"Geocoding request failed: {e}")
            raise WeatherServiceError(f"Network error while resolving location: {e}") from e
        except (KeyError, ValueError, TypeError) as e:
            logger.error(f"Malformed geocoding response: {e}")
            raise WeatherServiceError("Received malformed geocoding data.") from e
