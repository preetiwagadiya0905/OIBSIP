"""Domain models for weather data and forecasts."""

from dataclasses import dataclass


@dataclass(frozen=True)
class WeatherData:
    """Domain model representing validated weather information."""
    location: str
    temperature_celsius: float
    feels_like_celsius: float
    humidity: int
    description: str
    wind_speed: float
    country: str | None = None

    def to_speech_text(self) -> str:
        """Format weather into a natural, concise spoken response."""
        temp = round(self.temperature_celsius)
        feels = round(self.feels_like_celsius)
        desc = self.description.lower()
        loc = f"{self.location}, {self.country}" if self.country else self.location

        if temp == feels:
            return (
                f"The current weather in {loc} is {temp} degrees Celsius "
                f"with {desc}. Humidity is {self.humidity} percent."
            )
        return (
            f"The current weather in {loc} is {temp} degrees Celsius, "
            f"feels like {feels} degrees, with {desc}. Humidity is {self.humidity} percent."
        )
