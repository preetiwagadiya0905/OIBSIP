"""OpenWeatherMap HTTP API Client with validation and error translation."""

from typing import Any

import requests

from voice_assistant.config.settings import WeatherSettings
from voice_assistant.errors.exceptions import WeatherServiceError
from voice_assistant.observability.logging import get_logger
from voice_assistant.services.weather.geocoder import GeoCoordinates, OpenWeatherMapGeocoder
from voice_assistant.services.weather.models import WeatherData

logger = get_logger(__name__)


class OpenWeatherMapClient:
    """Production client for OpenWeatherMap 2.5 Weather API."""

    WEATHER_URL = "https://api.openweathermap.org/data/2.5/weather"

    def __init__(self, settings: WeatherSettings, geocoder: OpenWeatherMapGeocoder):
        self.settings = settings
        self.geocoder = geocoder

    def fetch_weather(self, location_query: str) -> WeatherData:
        """Resolve location and fetch current weather observations."""
        if not self.settings.is_configured:
            raise WeatherServiceError(
                "OpenWeatherMap API key is not configured. Please set OPENWEATHER_API_KEY in your .env file."
            )

        # 1. Geocode location query to coordinates
        coords: GeoCoordinates = self.geocoder.geocode(location_query)

        # 2. Query Current Weather Data endpoint with coordinates
        params: dict[str, Any] = {
            "lat": coords.latitude,
            "lon": coords.longitude,
            "appid": self.settings.api_key,
            "units": self.settings.units,
            "lang": self.settings.language,
        }

        try:
            logger.debug(f"Fetching weather for ({coords.latitude:.4f}, {coords.longitude:.4f})")
            response = requests.get(
                self.WEATHER_URL, params=params, timeout=self.settings.http_timeout
            )

            if response.status_code == 401:
                raise WeatherServiceError("Invalid OpenWeatherMap API key.")
            if response.status_code == 404:
                raise WeatherServiceError(f"Weather data not found for '{location_query}'.")
            if response.status_code == 429:
                raise WeatherServiceError("Weather API rate limit exceeded.")
            if response.status_code != 200:
                raise WeatherServiceError(
                    f"Weather API error (HTTP {response.status_code})."
                )

            data = response.json()
            return self._parse_weather_response(data, fallback_name=coords.name, country=coords.country)

        except requests.Timeout as e:
            logger.error(f"Weather API timeout: {e}")
            raise WeatherServiceError("Weather request timed out. Please check your connection.") from e
        except requests.RequestException as e:
            logger.error(f"Weather request failure: {e}")
            raise WeatherServiceError("Failed to fetch weather data due to a network error.") from e

    def _parse_weather_response(
        self, data: dict[str, Any], fallback_name: str, country: Any
    ) -> WeatherData:
        """Parse raw API dictionary into typed WeatherData domain model."""
        try:
            main = data.get("main", {})
            temp = float(main["temp"])
            feels_like = float(main.get("feels_like", temp))
            humidity = int(main.get("humidity", 0))

            weather_list = data.get("weather", [])
            description = weather_list[0].get("description", "Clear") if weather_list else "Clear"

            wind = data.get("wind", {})
            wind_speed = float(wind.get("speed", 0.0))

            loc_name = data.get("name") or fallback_name
            sys_obj = data.get("sys", {})
            resolved_country = sys_obj.get("country") or country

            return WeatherData(
                location=loc_name,
                temperature_celsius=temp,
                feels_like_celsius=feels_like,
                humidity=humidity,
                description=description.capitalize(),
                wind_speed=wind_speed,
                country=resolved_country,
            )
        except (KeyError, TypeError, IndexError, ValueError) as e:
            logger.error(f"Failed to parse weather API response schema: {e}")
            raise WeatherServiceError("Received malformed weather response from API.") from e
