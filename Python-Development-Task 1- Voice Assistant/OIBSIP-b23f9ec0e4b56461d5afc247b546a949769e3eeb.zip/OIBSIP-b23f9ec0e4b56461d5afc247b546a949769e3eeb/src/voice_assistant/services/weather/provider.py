"""Weather Provider interfaces and implementations."""

from typing import Protocol

from voice_assistant.errors.exceptions import WeatherServiceError
from voice_assistant.observability.logging import get_logger
from voice_assistant.services.weather.client import OpenWeatherMapClient
from voice_assistant.services.weather.models import WeatherData

logger = get_logger(__name__)


class WeatherProvider(Protocol):
    """Protocol for fetching weather data."""

    def get_weather(self, location: str) -> WeatherData:
        """Fetch weather data for the specified location."""
        ...


class OpenWeatherMapProvider:
    """Production provider using OpenWeatherMap client."""

    def __init__(self, client: OpenWeatherMapClient):
        self.client = client

    def get_weather(self, location: str) -> WeatherData:
        return self.client.fetch_weather(location)


class MockWeatherProvider:
    """Mock weather provider for unit tests and offline testing."""

    def __init__(self, predefined_data: dict[str, WeatherData] | None = None):
        self._data: dict[str, WeatherData] = predefined_data or {
            "hyderabad": WeatherData(
                location="Hyderabad",
                temperature_celsius=29.0,
                feels_like_celsius=31.0,
                humidity=72,
                description="Partly cloudy",
                wind_speed=3.5,
                country="IN",
            ),
            "london": WeatherData(
                location="London",
                temperature_celsius=18.0,
                feels_like_celsius=17.0,
                humidity=65,
                description="Light rain",
                wind_speed=4.2,
                country="GB",
            ),
            "new york": WeatherData(
                location="New York",
                temperature_celsius=22.0,
                feels_like_celsius=22.0,
                humidity=55,
                description="Clear sky",
                wind_speed=2.8,
                country="US",
            ),
        }

    def set_weather(self, location: str, data: WeatherData) -> None:
        self._data[location.lower().strip()] = data

    def get_weather(self, location: str) -> WeatherData:
        loc_key = location.lower().strip()
        if loc_key in self._data:
            return self._data[loc_key]
        # Return generic synthetic data for unknown test cities
        return WeatherData(
            location=location.title(),
            temperature_celsius=25.0,
            feels_like_celsius=26.0,
            humidity=60,
            description="Clear sky",
            wind_speed=3.0,
            country="World",
        )


class WeatherService:
    """Application service for weather queries."""

    def __init__(self, provider: WeatherProvider):
        self.provider = provider

    def get_weather(self, location: str) -> WeatherData:
        """Fetch weather data through the configured provider."""
        if not location or not location.strip():
            raise WeatherServiceError("Please specify a city or location name.")

        clean_location = location.strip()
        logger.info(f"Retrieving weather for location: '{clean_location}'")
        return self.provider.get_weather(clean_location)
