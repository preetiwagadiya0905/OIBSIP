"""Text processing, normalization, and spoken number/duration parsing utilities."""

import re

WORD_TO_NUMBER: dict[str, int] = {
    "zero": 0, "one": 1, "two": 2, "three": 3, "four": 4, "five": 5,
    "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10,
    "eleven": 11, "twelve": 12, "thirteen": 13, "fourteen": 14, "fifteen": 15,
    "sixteen": 16, "seventeen": 17, "eighteen": 18, "nineteen": 19, "twenty": 20,
    "thirty": 30, "forty": 40, "fifty": 50, "sixty": 60, "seventy": 70,
    "eighty": 80, "ninety": 90, "hundred": 100, "a": 1, "an": 1, "half": 0.5
}


def normalize_text(text: str) -> str:
    """Normalize text by lowering, stripping excess whitespace, and standardizing punctuation."""
    if not text:
        return ""
    cleaned = text.strip().lower()
    # Normalize spaces
    cleaned = re.sub(r"\s+", " ", cleaned)
    # Remove leading/trailing quotes and punctuation
    cleaned = cleaned.strip(" '\".,?!;:")
    return cleaned


def parse_spoken_number(token: str) -> float | None:
    """Convert a spoken word or digit string into a numeric value."""
    token = token.lower().strip()
    if token.isdigit():
        return float(token)
    try:
        return float(token)
    except ValueError:
        pass

    if token in WORD_TO_NUMBER:
        return float(WORD_TO_NUMBER[token])

    # Support compound words like "twenty-five" or "thirty two"
    parts = re.split(r"[- ]", token)
    if len(parts) == 2 and parts[0] in WORD_TO_NUMBER and parts[1] in WORD_TO_NUMBER:
        return float(WORD_TO_NUMBER[parts[0]] + WORD_TO_NUMBER[parts[1]])

    return None


def parse_duration_seconds(text: str) -> tuple[int, str] | None:
    """Extract a time duration in seconds and the remaining message text.

    Examples:
        "in 10 minutes to call John" -> (600, "call John")
        "after twenty seconds to check code" -> (20, "check code")
        "for 2 hours do laundry" -> (7200, "do laundry")
        "in a minute check pizza" -> (60, "check pizza")

    Returns:
        Tuple of (duration_in_seconds, remaining_task_description) or None if parsing fails.
    """
    normalized = normalize_text(text)

    # Regex matching patterns like:
    # (in|after|for)? (10|ten|half|a|an) (seconds?|secs?|minutes?|mins?|hours?|hrs?) (to|that|about)? (message)
    pattern = re.compile(
        r"(?:(?:remind me|set (?:a )?reminder)(?:\s+to)?\s*)?"
        r"(?:(?:in|after|for)\s+)?"
        r"(\d+(?:\.\d+)?|[a-z]+(?:\s+[a-z]+)?)\s*"
        r"(seconds?|secs?|minutes?|mins?|hours?|hrs?)"
        r"(?:\s+(?:to|that|about|for))?\s*(.*)",
        re.IGNORECASE
    )

    match = pattern.search(normalized)
    if not match:
        return None

    num_str, unit_str, message = match.groups()
    num = parse_spoken_number(num_str.strip())
    if num is None or num <= 0:
        return None

    unit_str = unit_str.lower().strip()
    multiplier = 1
    if unit_str.startswith("sec"):
        multiplier = 1
    elif unit_str.startswith("min"):
        multiplier = 60
    elif unit_str.startswith("hour") or unit_str.startswith("hr"):
        multiplier = 3600

    total_seconds = int(num * multiplier)
    task_description = message.strip() if message else "Reminder alert"

    # Clean up leading "to " or "that " from message if any
    task_description = re.sub(r"^(?:to|that|about|for)\s+", "", task_description, flags=re.IGNORECASE).strip()

    return total_seconds, task_description


def normalize_spoken_email(spoken_text: str) -> str:
    """Normalize spoken email text (e.g. 'john dot doe at gmail dot com' -> 'john.doe@gmail.com')."""
    text = spoken_text.strip().lower()
    text = re.sub(r"\s+at\s+", "@", text)
    text = re.sub(r"\s+dot\s+", ".", text)
    text = re.sub(r"\s+underscore\s+", "_", text)
    text = re.sub(r"\s+dash\s+", "-", text)
    text = re.sub(r"\s+", "", text)
    return text
