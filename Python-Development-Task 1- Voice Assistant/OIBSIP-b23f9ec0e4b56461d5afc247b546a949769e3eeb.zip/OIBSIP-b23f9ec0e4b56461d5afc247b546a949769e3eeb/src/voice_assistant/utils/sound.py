"""Audible alert generation utilities."""

import sys
import threading

from voice_assistant.observability.logging import get_logger

logger = get_logger(__name__)


def play_chime_async(frequency: int = 1000, duration_ms: int = 400) -> None:
    """Play a short chime or beep in a background daemon thread."""
    def _play() -> None:
        try:
            if sys.platform == "win32":
                import winsound
                winsound.Beep(frequency, duration_ms)
            else:
                # Terminal bell on POSIX systems
                sys.stdout.write("\a")
                sys.stdout.flush()
        except Exception as e:
            logger.debug(f"Could not generate hardware beep: {e}")

    thread = threading.Thread(target=_play, daemon=True)
    thread.start()
