"""FastAPI route handlers for speech commands, health, reminders, and SSE events."""

import asyncio
import json
from collections.abc import AsyncGenerator

from fastapi import APIRouter, Depends, HTTPException, Request, status
from fastapi.responses import StreamingResponse

from voice_assistant.config.settings import Settings
from voice_assistant.errors.exceptions import ReminderError
from voice_assistant.observability.logging import get_logger
from voice_assistant.services.reminders.scheduler import ReminderScheduler
from voice_assistant.web.rate_limiter import InMemoryRateLimiter
from voice_assistant.web.schemas import (
    AssistantRequest,
    AssistantResponse,
    ConfigResponse,
    HealthResponse,
    ReminderCreateRequest,
    ReminderItem,
    ReminderListResponse,
)
from voice_assistant.web.service_adapter import WebAssistantService
from voice_assistant.web.session import WebSessionRegistry

logger = get_logger(__name__)

router = APIRouter(prefix="/api")


def get_client_ip(request: Request) -> str:
    """Extract client IP from headers (supporting proxy X-Forwarded-For) or client host."""
    forwarded = request.headers.get("X-Forwarded-For")
    if forwarded:
        return forwarded.split(",")[0].strip()
    return request.client.host if request.client else "127.0.0.1"


def check_rate_limit(
    request: Request,
    rate_limiter: InMemoryRateLimiter = Depends(),
) -> None:
    """Enforce per-client IP rate limits."""
    client_ip = get_client_ip(request)
    if not rate_limiter.is_allowed(client_ip):
        logger.warning(f"Rate limit exceeded for client IP: {client_ip}")
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail="Rate limit exceeded. Please wait a moment before sending more requests.",
        )


@router.get("/health", response_model=HealthResponse)
async def health_check(request: Request) -> HealthResponse:
    """Service health and liveness probe."""
    settings: Settings = request.app.state.settings
    return HealthResponse(
        status="healthy",
        app_name=settings.app_name,
        environment=settings.app_env.value,
        version="1.0.0",
    )


@router.get("/config", response_model=ConfigResponse)
async def get_public_config(request: Request) -> ConfigResponse:
    """Return public application configuration safe for browser frontend."""
    settings: Settings = request.app.state.settings
    return ConfigResponse(
        app_name=settings.app_name,
        version="1.0.0",
        weather_enabled=settings.weather.is_configured,
        email_enabled=settings.web.enable_public_email and settings.smtp.is_configured,
        nlp_threshold=settings.nlp.confidence_threshold,
    )


@router.post("/assistant", response_model=AssistantResponse)
async def process_utterance(
    req: AssistantRequest,
    request: Request,
) -> AssistantResponse:
    """Primary endpoint for speech transcription and typed text commands."""
    # Apply rate limiting
    limiter: InMemoryRateLimiter = request.app.state.rate_limiter
    client_ip = get_client_ip(request)
    if not limiter.is_allowed(client_ip):
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail="Too many requests. Please slow down.",
        )

    session_registry: WebSessionRegistry = request.app.state.session_registry
    user_session = session_registry.get_or_create(req.session_id)

    service: WebAssistantService = request.app.state.web_service
    return service.process_request(req, user_session)


@router.get("/events/{session_id}")
async def sse_event_stream(
    session_id: str,
    request: Request,
) -> StreamingResponse:
    """Server-Sent Events (SSE) stream delivering real-time background reminder alerts to browser."""
    session_registry: WebSessionRegistry = request.app.state.session_registry
    user_session = session_registry.get_or_create(session_id)

    event_queue: asyncio.Queue = asyncio.Queue()
    user_session.add_queue(event_queue)

    async def event_generator() -> AsyncGenerator[str, None]:
        logger.info(f"SSE stream opened for web session: {session_id}")
        try:
            # Send initial connection event
            yield f"event: ping\ndata: {json.dumps({'status': 'connected'})}\n\n"

            while True:
                # Check for client disconnect
                if await request.is_disconnected():
                    break

                try:
                    # Wait for reminder event with 15s heartbeat timeout
                    event = await asyncio.wait_for(event_queue.get(), timeout=15.0)
                    yield f"event: message\ndata: {json.dumps(event)}\n\n"
                except asyncio.TimeoutError:
                    # Send keep-alive comment
                    yield ": keepalive\n\n"

        except asyncio.CancelledError:
            pass
        finally:
            user_session.remove_queue(event_queue)
            logger.info(f"SSE stream closed for web session: {session_id}")

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


@router.get("/reminders", response_model=ReminderListResponse)
async def list_active_reminders(
    request: Request,
) -> ReminderListResponse:
    """List active scheduled reminders."""
    scheduler: ReminderScheduler = request.app.state.reminder_scheduler
    active = scheduler.list_active()
    items = [
        ReminderItem(
            id=r.id,
            message=r.message,
            duration_seconds=r.duration_seconds,
            human_duration=r.human_duration,
            status=r.status.value,
            created_at=r.created_at.isoformat(),
        )
        for r in active
    ]
    return ReminderListResponse(success=True, reminders=items)


@router.post("/reminders", response_model=AssistantResponse)
async def create_reminder(
    req: ReminderCreateRequest,
    request: Request,
) -> AssistantResponse:
    """Directly schedule a reminder for the session."""
    session_registry: WebSessionRegistry = request.app.state.session_registry
    user_session = session_registry.get_or_create(req.session_id)
    scheduler: ReminderScheduler = request.app.state.reminder_scheduler

    try:
        reminder = scheduler.schedule(
            duration_seconds=req.duration_seconds,
            message=req.message,
        )
        session_registry.register_reminder(reminder.id, user_session.session_id)

        msg = f"I will remind you in {reminder.human_duration} to {reminder.message}."
        return AssistantResponse(
            success=True,
            intent="SET_REMINDER",
            confidence=1.0,
            response=msg,
            action="SPEAK",
            data={"reminder_id": reminder.id, "duration": reminder.duration_seconds},
            session_id=user_session.session_id,
        )
    except ReminderError as e:
        raise HTTPException(status_code=400, detail=e.message) from e
