"""FastAPI Application factory, middleware, static file serving, and error handling."""

from pathlib import Path

from fastapi import FastAPI, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from voice_assistant.commands.custom import CustomCommandsCommand
from voice_assistant.commands.datetime import DateTimeCommand
from voice_assistant.commands.email import EmailCommand
from voice_assistant.commands.greeting import GreetingCommand
from voice_assistant.commands.help_exit import CancelCommand, ExitCommand, HelpCommand
from voice_assistant.commands.knowledge import KnowledgeCommand
from voice_assistant.commands.registry import CommandRegistry
from voice_assistant.commands.reminder import ReminderCommand
from voice_assistant.commands.weather import WeatherCommand
from voice_assistant.commands.web_search import WebSearchCommand
from voice_assistant.config.settings import Settings
from voice_assistant.nlp.classifier import HybridIntentClassifier
from voice_assistant.nlp.parser import NLUParser
from voice_assistant.observability.logging import get_logger, setup_logging
from voice_assistant.services.email.client import SMTPEmailClient
from voice_assistant.services.email.provider import (
    EmailService,
    MockEmailProvider,
    SMTPEmailProvider,
)
from voice_assistant.services.knowledge.client import (
    DuckDuckGoKnowledgeClient,
    WikipediaKnowledgeClient,
)
from voice_assistant.services.knowledge.provider import (
    CompositeKnowledgeProvider,
    KnowledgeService,
    LocalCuratedKnowledgeProvider,
)
from voice_assistant.services.reminders.scheduler import ReminderScheduler
from voice_assistant.services.weather.client import OpenWeatherMapClient
from voice_assistant.services.weather.geocoder import OpenWeatherMapGeocoder
from voice_assistant.services.weather.provider import (
    MockWeatherProvider,
    OpenWeatherMapProvider,
    WeatherService,
)
from voice_assistant.storage.custom_commands import CustomCommandsStorage
from voice_assistant.web.rate_limiter import InMemoryRateLimiter
from voice_assistant.web.routes import router
from voice_assistant.web.service_adapter import WebAssistantService
from voice_assistant.web.session import WebSessionRegistry

logger = get_logger(__name__)


def create_app(
    settings: Settings | None = None,
    custom_weather_service: WeatherService | None = None,
    custom_email_service: EmailService | None = None,
) -> FastAPI:
    """Create and configure the production FastAPI application."""
    app_settings = settings or Settings.load()
    setup_logging(log_level=app_settings.log_level)

    app = FastAPI(
        title="Aura Web Voice Assistant",
        description="Full-stack AI Voice Assistant with browser-side Web Speech & Text-to-Speech",
        version="1.0.0",
        docs_url="/api/docs",
        redoc_url="/api/redoc",
    )

    # 1. CORS Configuration
    origins = app_settings.web.cors_origins
    app.add_middleware(
        CORSMiddleware,
        allow_origins=origins if origins else ["*"],
        allow_credentials=True,
        allow_methods=["GET", "POST", "DELETE", "OPTIONS"],
        allow_headers=["*"],
    )

    # 2. Dependency Wiring
    # NLP
    classifier = HybridIntentClassifier(confidence_threshold=app_settings.nlp.confidence_threshold)
    nlu_parser = NLUParser(classifier=classifier, confidence_threshold=app_settings.nlp.confidence_threshold)

    # Storage
    custom_storage = CustomCommandsStorage(app_settings.storage.commands_path)

    # Weather Service
    if custom_weather_service:
        weather_service = custom_weather_service
    elif app_settings.weather.is_configured:
        geocoder = OpenWeatherMapGeocoder(
            api_key=app_settings.weather.api_key,
            timeout=app_settings.weather.http_timeout,
        )
        weather_client = OpenWeatherMapClient(
            settings=app_settings.weather,
            geocoder=geocoder,
        )
        weather_service = WeatherService(OpenWeatherMapProvider(weather_client))
    else:
        weather_service = WeatherService(MockWeatherProvider())

    # Email Service
    if custom_email_service:
        email_service = custom_email_service
    elif app_settings.smtp.is_configured and app_settings.web.enable_public_email:
        email_client = SMTPEmailClient(app_settings.smtp)
        email_service = EmailService(SMTPEmailProvider(email_client))
    else:
        email_service = EmailService(MockEmailProvider())

    # Reminders & Knowledge
    reminder_scheduler = ReminderScheduler()
    wiki_client = WikipediaKnowledgeClient(timeout=app_settings.weather.http_timeout)
    ddg_client = DuckDuckGoKnowledgeClient(timeout=app_settings.weather.http_timeout)
    local_curated = LocalCuratedKnowledgeProvider()
    knowledge_service = KnowledgeService(
        CompositeKnowledgeProvider(wiki_client, ddg_client, local_curated)
    )

    # Session & Rate Limiting
    session_registry = WebSessionRegistry()
    rate_limiter = InMemoryRateLimiter(requests_per_minute=app_settings.web.rate_limit_per_minute)

    # Temporary placeholder session manager for command instantiation
    from voice_assistant.application.session import SessionManager
    dummy_session_manager = SessionManager()

    # Command Registry
    command_registry = CommandRegistry()
    command_registry.register(GreetingCommand())
    command_registry.register(DateTimeCommand())
    command_registry.register(WebSearchCommand())
    command_registry.register(WeatherCommand(weather_service))
    command_registry.register(ReminderCommand(reminder_scheduler))
    command_registry.register(EmailCommand(email_service, dummy_session_manager))
    command_registry.register(KnowledgeCommand(knowledge_service))
    command_registry.register(CustomCommandsCommand(custom_storage))
    command_registry.register(HelpCommand())
    command_registry.register(ExitCommand())
    command_registry.register(CancelCommand(dummy_session_manager))

    # Web Assistant Service
    web_service = WebAssistantService(
        settings=app_settings,
        nlu_parser=nlu_parser,
        command_registry=command_registry,
        custom_storage=custom_storage,
        reminder_scheduler=reminder_scheduler,
        session_registry=session_registry,
    )

    # Store state on FastAPI app instance
    app.state.settings = app_settings
    app.state.session_registry = session_registry
    app.state.rate_limiter = rate_limiter
    app.state.reminder_scheduler = reminder_scheduler
    app.state.web_service = web_service

    # 3. Global Exception Handler (Safe error responses)
    @app.exception_handler(Exception)
    async def global_exception_handler(request: Request, exc: Exception):
        logger.error(f"Unhandled error on {request.url.path}: {exc}", exc_info=True)
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={
                "success": False,
                "intent": "UNKNOWN",
                "confidence": 0.0,
                "response": "The assistant encountered an internal error. Please try again.",
                "action": "SPEAK",
                "session_id": "",
                "in_conversation": False,
            },
        )

    # 4. Include API routes
    app.include_router(router)

    # 5. Static Files & Root Frontend serving
    static_dir = Path(__file__).resolve().parent / "static"
    if static_dir.exists():
        app.mount("/static", StaticFiles(directory=str(static_dir)), name="static")

        @app.get("/", include_in_schema=False)
        async def serve_index():
            index_path = static_dir / "index.html"
            if index_path.exists():
                return FileResponse(str(index_path))
            return JSONResponse({"message": "Aura Voice Assistant API is running."})

    return app


# Module-level default application instance for uvicorn
app = create_app()
