"""Web service adapter executing NLU and Commands with per-user isolation."""

import urllib.parse

from voice_assistant.commands.base import CommandContext, CommandResult
from voice_assistant.commands.registry import CommandRegistry
from voice_assistant.config.constants import CustomActionType, IntentType
from voice_assistant.config.settings import Settings
from voice_assistant.errors.exceptions import CommandNotFoundError
from voice_assistant.nlp.intent import IntentResult
from voice_assistant.nlp.parser import NLUParser
from voice_assistant.observability.logging import get_logger
from voice_assistant.services.reminders.scheduler import ReminderScheduler
from voice_assistant.storage.custom_commands import CustomCommandsStorage
from voice_assistant.web.schemas import AssistantRequest, AssistantResponse
from voice_assistant.web.session import UserWebSession, WebSessionRegistry

logger = get_logger(__name__)


class WebAssistantService:
    """Service handling web client requests with isolated multi-turn state."""

    def __init__(
        self,
        settings: Settings,
        nlu_parser: NLUParser,
        command_registry: CommandRegistry,
        custom_storage: CustomCommandsStorage,
        reminder_scheduler: ReminderScheduler,
        session_registry: WebSessionRegistry,
    ):
        self.settings = settings
        self.nlu_parser = nlu_parser
        self.command_registry = command_registry
        self.custom_storage = custom_storage
        self.reminder_scheduler = reminder_scheduler
        self.session_registry = session_registry

        # Connect reminder scheduler to session registry for SSE push
        self.reminder_scheduler.set_alert_callback(self.session_registry.notify_reminder_fired)

    def process_request(self, req: AssistantRequest, user_session: UserWebSession) -> AssistantResponse:
        """Execute speech/text command for a specific web user session."""
        raw_text = req.message.strip()
        session_manager = user_session.session_manager
        user_session.touch()

        logger.info(f"Web session [{user_session.session_id}] processing: '{raw_text}'")

        context = CommandContext(
            services={
                "settings": self.settings,
                "session_manager": session_manager,
                "custom_storage": self.custom_storage,
                "reminder_scheduler": self.reminder_scheduler,
            }
        )

        # 1. Check if user is in an active conversational multi-turn session (e.g. Email composition)
        if session_manager.has_active_session:
            intent_result = self.nlu_parser.parse(raw_text)
            if intent_result.intent == IntentType.CANCEL:
                session_manager.clear()
                return AssistantResponse(
                    success=True,
                    intent=IntentType.CANCEL.value,
                    confidence=1.0,
                    response="Operation cancelled.",
                    action="SPEAK",
                    session_id=user_session.session_id,
                    in_conversation=False,
                )

            # Route to email command handler
            try:
                cmd = self.command_registry.get_command(IntentType.SEND_EMAIL)
                result: CommandResult = cmd.execute(intent_result, context)
                in_conv = session_manager.has_active_session
                return AssistantResponse(
                    success=result.success,
                    intent=IntentType.SEND_EMAIL.value,
                    confidence=intent_result.confidence,
                    response=result.response_text,
                    action="SPEAK",
                    session_id=user_session.session_id,
                    in_conversation=in_conv,
                )
            except Exception as e:
                logger.error(f"Web session multi-turn execution error: {e}")
                return AssistantResponse(
                    success=False,
                    intent=IntentType.UNKNOWN.value,
                    confidence=0.0,
                    response="Could not process conversational input.",
                    action="SPEAK",
                    session_id=user_session.session_id,
                    in_conversation=False,
                )

        # 2. Check registered custom commands
        custom_cmd = self.custom_storage.get_command(raw_text)
        if custom_cmd:
            if custom_cmd.action == CustomActionType.OPEN_URL:
                return AssistantResponse(
                    success=True,
                    intent=IntentType.CUSTOM_COMMAND.value,
                    confidence=1.0,
                    response=f"Opening {custom_cmd.name}.",
                    action="OPEN_URL",
                    data={"url": custom_cmd.target},
                    session_id=user_session.session_id,
                    in_conversation=False,
                )
            elif custom_cmd.action == CustomActionType.SPEAK:
                return AssistantResponse(
                    success=True,
                    intent=IntentType.CUSTOM_COMMAND.value,
                    confidence=1.0,
                    response=custom_cmd.target,
                    action="SPEAK",
                    session_id=user_session.session_id,
                    in_conversation=False,
                )

        # 3. Parse intent with NLU pipeline
        intent_result: IntentResult = self.nlu_parser.parse(raw_text)

        # 4. Handle low-confidence clarification
        if intent_result.requires_clarification and intent_result.clarification_prompt:
            return AssistantResponse(
                success=True,
                intent=intent_result.intent.value,
                confidence=intent_result.confidence,
                response=intent_result.clarification_prompt,
                action="CLARIFY",
                session_id=user_session.session_id,
                in_conversation=False,
            )

        # 5. Handle UNKNOWN intent
        if intent_result.intent == IntentType.UNKNOWN:
            msg = "I'm not sure how to help with that yet. Try saying 'help' to hear what I can do."
            return AssistantResponse(
                success=False,
                intent=IntentType.UNKNOWN.value,
                confidence=0.0,
                response=msg,
                action="SPEAK",
                session_id=user_session.session_id,
                in_conversation=False,
            )

        # 6. Specialized handling for WEB_SEARCH (return URL for browser to open)
        if intent_result.intent == IntentType.WEB_SEARCH:
            query = intent_result.entities.get("query") or intent_result.normalized_text.strip()
            encoded_query = urllib.parse.urlencode({"q": query})
            search_url = f"https://www.google.com/search?{encoded_query}"
            return AssistantResponse(
                success=True,
                intent=IntentType.WEB_SEARCH.value,
                confidence=intent_result.confidence,
                response=f"Searching the web for {query}.",
                action="OPEN_URL",
                data={"url": search_url, "query": query},
                session_id=user_session.session_id,
                in_conversation=False,
            )

        # 7. Execute registered command
        try:
            command = self.command_registry.get_command(intent_result.intent)
            result = command.execute(intent_result, context)

            # If a reminder was created, register it to this user's session for push notifications
            if intent_result.intent == IntentType.SET_REMINDER and result.success and "reminder_id" in result.data:
                rem_id = result.data["reminder_id"]
                self.session_registry.register_reminder(rem_id, user_session.session_id)
                logger.debug(f"Linked reminder {rem_id} to web session {user_session.session_id}")

            in_conv = session_manager.has_active_session
            action = "SPEAK"
            if intent_result.intent == IntentType.EXIT:
                action = "EXIT"

            return AssistantResponse(
                success=result.success,
                intent=intent_result.intent.value,
                confidence=intent_result.confidence,
                response=result.response_text,
                action=action,
                data=result.data,
                session_id=user_session.session_id,
                in_conversation=in_conv,
            )

        except CommandNotFoundError:
            return AssistantResponse(
                success=False,
                intent=intent_result.intent.value,
                confidence=intent_result.confidence,
                response="I recognize that command, but no handler is configured.",
                action="SPEAK",
                session_id=user_session.session_id,
                in_conversation=False,
            )
        except Exception as e:
            logger.error(f"Command execution error: {e}")
            return AssistantResponse(
                success=False,
                intent=intent_result.intent.value,
                confidence=intent_result.confidence,
                response="An unexpected error occurred while executing the command.",
                action="SPEAK",
                session_id=user_session.session_id,
                in_conversation=False,
            )
