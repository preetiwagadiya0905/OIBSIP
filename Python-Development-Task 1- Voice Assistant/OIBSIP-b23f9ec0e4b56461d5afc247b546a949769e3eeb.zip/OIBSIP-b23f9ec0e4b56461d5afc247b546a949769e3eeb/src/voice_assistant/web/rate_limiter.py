"""In-memory sliding window rate limiter for public Web API protection."""

import threading
import time
from collections import defaultdict


class InMemoryRateLimiter:
    """Sliding-window rate limiter per client IP / identifier."""

    def __init__(self, requests_per_minute: int = 60, window_seconds: float = 60.0):
        self.requests_per_minute = requests_per_minute
        self.window_seconds = window_seconds
        self._requests: dict[str, list[float]] = defaultdict(list)
        self._lock = threading.Lock()

    def is_allowed(self, client_key: str) -> bool:
        """Check if request from client_key is allowed under rate limits."""
        now = time.time()
        cutoff = now - self.window_seconds

        with self._lock:
            # Purge timestamps outside sliding window
            timestamps = [t for t in self._requests[client_key] if t > cutoff]
            if len(timestamps) >= self.requests_per_minute:
                self._requests[client_key] = timestamps
                return False

            timestamps.append(now)
            self._requests[client_key] = timestamps
            return True

    def get_remaining(self, client_key: str) -> int:
        """Get remaining requests in the current window."""
        now = time.time()
        cutoff = now - self.window_seconds

        with self._lock:
            timestamps = [t for t in self._requests[client_key] if t > cutoff]
            self._requests[client_key] = timestamps
            return max(0, self.requests_per_minute - len(timestamps))

    def cleanup(self) -> None:
        """Periodically purge inactive client records."""
        now = time.time()
        cutoff = now - self.window_seconds
        with self._lock:
            keys_to_remove = [
                key for key, timestamps in self._requests.items()
                if not timestamps or timestamps[-1] <= cutoff
            ]
            for key in keys_to_remove:
                del self._requests[key]
