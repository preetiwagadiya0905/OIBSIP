"""Web package for FastAPI application, schemas, and routes."""

from voice_assistant.web.app import app, create_app

__all__ = ["app", "create_app"]
