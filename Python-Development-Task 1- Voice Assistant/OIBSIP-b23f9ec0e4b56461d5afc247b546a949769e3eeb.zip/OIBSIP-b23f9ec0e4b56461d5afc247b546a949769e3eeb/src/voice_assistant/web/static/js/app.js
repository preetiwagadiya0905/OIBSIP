/**
 * Aura Voice Assistant - Client-side Controller
 * Handles Web Speech Recognition, Web Speech Synthesis, SSE reminder events, and REST communication.
 */

class AuraVoiceApp {
  constructor() {
    this.sessionId = this.getOrCreateSessionId();
    this.ttsEnabled = true;
    this.isListening = false;
    this.isSpeaking = false;
    this.recognition = null;
    this.speechSynth = window.speechSynthesis || null;
    this.audioCtx = null;

    this.initElements();
    this.initSpeechRecognition();
    this.initEventListeners();
    this.initServerEventsStream();
    this.fetchConfig();
  }

  getOrCreateSessionId() {
    let sid = localStorage.getItem('aura_session_id');
    if (!sid) {
      sid = 'session_' + Math.random().toString(36).substring(2, 11) + '_' + Date.now();
      localStorage.setItem('aura_session_id', sid);
    }
    return sid;
  }

  initElements() {
    this.micBtn = document.getElementById('micBtn');
    this.micStage = document.querySelector('.mic-stage');
    this.statusBadge = document.getElementById('statusBadge');
    this.statusText = document.getElementById('statusText');
    this.voiceInstruction = document.getElementById('voiceInstruction');
    this.liveTranscription = document.getElementById('liveTranscription');
    this.chatStream = document.getElementById('chatStream');
    this.inputForm = document.getElementById('inputForm');
    this.textInput = document.getElementById('textInput');
    this.ttsToggleBtn = document.getElementById('ttsToggleBtn');
    this.ttsIconOn = document.getElementById('ttsIconOn');
    this.ttsIconOff = document.getElementById('ttsIconOff');
    this.clearChatBtn = document.getElementById('clearChatBtn');
    this.toastContainer = document.getElementById('toastContainer');
    this.welcomeTime = document.getElementById('welcomeTime');

    if (this.welcomeTime) {
      this.welcomeTime.textContent = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    }
  }

  initSpeechRecognition() {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      console.warn('Web Speech API (SpeechRecognition) is not supported in this browser.');
      this.voiceInstruction.textContent = 'Voice input not supported in this browser. Please use the text input below.';
      return;
    }

    this.recognition = new SpeechRecognition();
    this.recognition.continuous = false;
    this.recognition.interimResults = true;
    this.recognition.lang = 'en-US';

    this.recognition.onstart = () => {
      this.isListening = true;
      this.setVisualState('listening', 'Listening...');
      this.voiceInstruction.textContent = 'Listening to your voice...';
      this.liveTranscription.textContent = '';
    };

    this.recognition.onresult = (event) => {
      let interim = '';
      let finalTranscript = '';
      for (let i = event.resultIndex; i < event.results.length; ++i) {
        if (event.results[i].isFinal) {
          finalTranscript += event.results[i][0].transcript;
        } else {
          interim += event.results[i][0].transcript;
        }
      }
      this.liveTranscription.textContent = finalTranscript || interim;
      if (finalTranscript) {
        this.stopListening();
        this.sendCommand(finalTranscript.trim());
      }
    };

    this.recognition.onerror = (event) => {
      console.warn('Speech recognition error:', event.error);
      this.isListening = false;
      this.setVisualState('ready', 'Ready');
      if (event.error === 'not-allowed') {
        this.voiceInstruction.textContent = 'Microphone permission denied. Please allow mic access or use text input.';
        this.showToast('Microphone permission denied.', 'error');
      } else if (event.error === 'no-speech') {
        this.voiceInstruction.textContent = 'No speech detected. Tap the mic to try again.';
      } else {
        this.voiceInstruction.textContent = `Speech error: ${event.error}. Tap mic to retry.`;
      }
    };

    this.recognition.onend = () => {
      this.isListening = false;
      if (this.statusText.textContent === 'Listening...') {
        this.setVisualState('ready', 'Ready');
        this.voiceInstruction.textContent = 'Tap the microphone and start speaking';
      }
    };
  }

  initEventListeners() {
    // Mic button
    this.micBtn.addEventListener('click', () => {
      if (this.isSpeaking) {
        this.stopSpeaking();
      }
      if (this.isListening) {
        this.stopListening();
      } else {
        this.startListening();
      }
    });

    // Form submit
    this.inputForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const text = this.textInput.value.trim();
      if (!text) return;
      this.textInput.value = '';
      this.sendCommand(text);
    });

    // TTS Toggle
    this.ttsToggleBtn.addEventListener('click', () => {
      this.ttsEnabled = !this.ttsEnabled;
      this.ttsIconOn.classList.toggle('hidden', !this.ttsEnabled);
      this.ttsIconOff.classList.toggle('hidden', this.ttsEnabled);
      if (!this.ttsEnabled) {
        this.stopSpeaking();
        this.showToast('Spoken voice muted', 'info');
      } else {
        this.showToast('Spoken voice enabled', 'info');
      }
    });

    // Clear history
    this.clearChatBtn.addEventListener('click', () => {
      this.chatStream.innerHTML = '';
      this.appendMessage('assistant', 'Conversation cleared. How can I help you today?');
    });

    // Capabilities pills
    document.querySelectorAll('.pill').forEach((pill) => {
      pill.addEventListener('click', () => {
        const query = pill.getAttribute('data-query');
        if (query) {
          this.sendCommand(query);
        }
      });
    });
  }

  startListening() {
    if (!this.recognition) {
      this.showToast('Speech recognition not supported on this browser. Type below!', 'warning');
      this.textInput.focus();
      return;
    }
    try {
      this.recognition.start();
    } catch (e) {
      console.debug('Recognition restart:', e);
    }
  }

  stopListening() {
    if (this.recognition && this.isListening) {
      this.recognition.stop();
      this.isListening = false;
    }
  }

  setVisualState(state, text) {
    this.statusBadge.className = `status-badge ${state}`;
    this.statusText.textContent = text;
    this.micStage.className = `mic-stage ${state}`;
  }

  async sendCommand(message) {
    if (!message) return;

    this.appendMessage('user', message);
    this.setVisualState('processing', 'Processing...');
    this.voiceInstruction.textContent = 'Processing request...';
    this.liveTranscription.textContent = '';

    try {
      const response = await fetch('/api/assistant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: message,
          session_id: this.sessionId,
        }),
      });

      if (!response.ok) {
        const err = await response.json();
        throw new Error(err.detail || 'Assistant request failed');
      }

      const data = await response.json();
      this.handleAssistantResponse(data);

    } catch (error) {
      console.error('Error contacting assistant API:', error);
      this.setVisualState('ready', 'Error');
      this.voiceInstruction.textContent = 'Could not process request. Tap mic or type below.';
      this.appendMessage('assistant', 'Sorry, I encountered an issue connecting to the server.');
      this.showToast(error.message || 'Connection error', 'error');
    }
  }

  handleAssistantResponse(data) {
    const responseText = data.response || 'No response';
    this.appendMessage('assistant', responseText);

    // If backend returned an action like opening a web search URL
    if (data.action === 'OPEN_URL' && data.data && data.data.url) {
      window.open(data.data.url, '_blank');
    }

    // Speak response if TTS is enabled
    if (this.ttsEnabled && responseText) {
      this.speakText(responseText);
    } else {
      this.setVisualState('ready', 'Ready');
      this.voiceInstruction.textContent = 'Tap the microphone and start speaking';
    }
  }

  speakText(text) {
    if (!this.speechSynth) {
      this.setVisualState('ready', 'Ready');
      return;
    }

    this.stopSpeaking();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1.0;
    utterance.pitch = 1.0;
    utterance.lang = 'en-US';

    utterance.onstart = () => {
      this.isSpeaking = true;
      this.setVisualState('speaking', 'Speaking...');
      this.voiceInstruction.textContent = 'Aura is speaking...';
    };

    utterance.onend = () => {
      this.isSpeaking = false;
      this.setVisualState('ready', 'Ready');
      this.voiceInstruction.textContent = 'Tap the microphone and start speaking';
    };

    utterance.onerror = () => {
      this.isSpeaking = false;
      this.setVisualState('ready', 'Ready');
      this.voiceInstruction.textContent = 'Tap the microphone and start speaking';
    };

    this.speechSynth.speak(utterance);
  }

  stopSpeaking() {
    if (this.speechSynth && this.speechSynth.speaking) {
      this.speechSynth.cancel();
      this.isSpeaking = false;
    }
  }

  appendMessage(sender, text) {
    const msgDiv = document.createElement('div');
    msgDiv.className = `chat-message ${sender === 'user' ? 'user-msg' : 'assistant-msg'}`;

    const avatar = document.createElement('div');
    avatar.className = 'msg-avatar';
    avatar.textContent = sender === 'user' ? 'U' : 'A';

    const content = document.createElement('div');
    content.className = 'msg-content';

    const p = document.createElement('p');
    p.textContent = text;

    const time = document.createElement('span');
    time.className = 'msg-time';
    time.textContent = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    content.appendChild(p);
    content.appendChild(time);
    msgDiv.appendChild(avatar);
    msgDiv.appendChild(content);

    this.chatStream.appendChild(msgDiv);
    this.chatStream.scrollTop = this.chatStream.scrollHeight;
  }

  playChimeSound() {
    try {
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      if (!AudioContext) return;
      if (!this.audioCtx) {
        this.audioCtx = new AudioContext();
      }
      const osc = this.audioCtx.createOscillator();
      const gain = this.audioCtx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(587.33, this.audioCtx.currentTime); // D5
      osc.frequency.setValueAtTime(880.00, this.audioCtx.currentTime + 0.15); // A5

      gain.gain.setValueAtTime(0.3, this.audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, this.audioCtx.currentTime + 0.5);

      osc.connect(gain);
      gain.connect(this.audioCtx.destination);

      osc.start();
      osc.stop(this.audioCtx.currentTime + 0.5);
    } catch (e) {
      console.debug('Chime audio error:', e);
    }
  }

  initServerEventsStream() {
    const sseUrl = `/api/events/${this.sessionId}`;
    const eventSource = new EventSource(sseUrl);

    eventSource.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        if (data.type === 'REMINDER_ALERT') {
          this.playChimeSound();
          const alertMsg = `⏰ Reminder: ${data.message}`;
          this.appendMessage('assistant', alertMsg);
          this.showToast(alertMsg, 'info');
          if (this.ttsEnabled) {
            this.speakText(`Reminder: ${data.message}`);
          }
        }
      } catch (e) {
        console.debug('SSE parse error:', e);
      }
    };

    eventSource.onerror = (e) => {
      console.debug('SSE stream disconnected, will reconnect automatically:', e);
    };
  }

  showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.textContent = message;

    this.toastContainer.appendChild(toast);
    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(10px)';
      setTimeout(() => toast.remove(), 300);
    }, 4000);
  }

  async fetchConfig() {
    try {
      const res = await fetch('/api/config');
      if (res.ok) {
        const cfg = await res.json();
        console.info(`Aura Web Voice Assistant v${cfg.version} initialized.`);
      }
    } catch (e) {
      console.debug('Could not fetch public config:', e);
    }
  }
}

// Instantiate on DOM ready
document.addEventListener('DOMContentLoaded', () => {
  window.auraApp = new AuraVoiceApp();
});
