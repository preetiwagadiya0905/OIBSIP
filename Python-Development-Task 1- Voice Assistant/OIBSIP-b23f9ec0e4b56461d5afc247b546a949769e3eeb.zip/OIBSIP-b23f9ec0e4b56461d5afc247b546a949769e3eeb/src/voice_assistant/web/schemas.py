"""Pydantic schemas for the Voice Assistant Web API."""

from typing import Any

from pydantic import BaseModel, Field


class AssistantRequest(BaseModel):
    """Payload for user speech or text input."""
    message: str = Field(..., min_length=1, max_length=2000, description="The user's speech transcription or typed command.")
    session_id: str | None = Field(None, max_length=128, description="Unique client session identifier for multi-turn conversations.")


class AssistantResponse(BaseModel):
    """Assistant execution response."""
    success: bool = True
    intent: str
    confidence: float
    response: str
    action: str | None = None
    data: dict[str, Any] = Field(default_factory=dict)
    session_id: str
    in_conversation: bool = False


class ReminderCreateRequest(BaseModel):
    """Payload to create a reminder directly."""
    duration_seconds: int = Field(..., ge=1, le=2592000, description="Duration in seconds.")
    message: str = Field(..., min_length=1, max_length=500, description="Reminder task or message.")
    session_id: str | None = None


class ReminderItem(BaseModel):
    """Representation of an active reminder."""
    id: str
    message: str
    duration_seconds: int
    human_duration: str
    status: str
    created_at: str


class ReminderListResponse(BaseModel):
    """List of active reminders for the session."""
    success: bool = True
    reminders: list[ReminderItem]


class HealthResponse(BaseModel):
    """System health check response."""
    status: str = "healthy"
    app_name: str
    environment: str
    version: str = "1.0.0"


class ConfigResponse(BaseModel):
    """Public application capabilities configuration (safe for frontend)."""
    app_name: str
    version: str = "1.0.0"
    weather_enabled: bool
    email_enabled: bool
    nlp_threshold: float
