"""Multi-user session registry and real-time SSE reminder dispatch queue."""

import asyncio
import threading
import time
import uuid

from voice_assistant.application.session import SessionManager
from voice_assistant.observability.logging import get_logger
from voice_assistant.services.reminders.models import Reminder

logger = get_logger(__name__)


class UserWebSession:
    """Encapsulates per-user isolated state, conversational memory, and event queues."""

    def __init__(self, session_id: str, timeout_seconds: float = 3600.0):
        self.session_id = session_id
        self.session_manager = SessionManager(default_timeout=120.0)
        self.created_at = time.time()
        self.last_activity = time.time()
        self.timeout_seconds = timeout_seconds
        self.event_queues: list[asyncio.Queue] = []
        self._lock = threading.Lock()

    @property
    def is_expired(self) -> bool:
        return (time.time() - self.last_activity) > self.timeout_seconds

    def touch(self) -> None:
        self.last_activity = time.time()

    def add_queue(self, queue: asyncio.Queue) -> None:
        with self._lock:
            self.event_queues.append(queue)

    def remove_queue(self, queue: asyncio.Queue) -> None:
        with self._lock:
            if queue in self.event_queues:
                self.event_queues.remove(queue)

    def push_event(self, event: dict) -> None:
        """Broadcast an event to all active SSE streams connected to this user session."""
        with self._lock:
            for q in self.event_queues:
                try:
                    q.put_nowait(event)
                except Exception as e:
                    logger.debug(f"Could not push event to queue for session {self.session_id}: {e}")


class WebSessionRegistry:
    """Thread-safe registry managing isolated sessions across multiple browser visitors."""

    def __init__(self, session_ttl: float = 7200.0):
        self.session_ttl = session_ttl
        self._sessions: dict[str, UserWebSession] = {}
        self._reminder_to_session: dict[str, str] = {}
        self._lock = threading.Lock()

    def get_or_create(self, session_id: str | None = None) -> UserWebSession:
        """Retrieve existing session or create a new one."""
        with self._lock:
            sid = session_id.strip() if session_id and session_id.strip() else str(uuid.uuid4())

            # Cleanup expired session if needed
            existing = self._sessions.get(sid)
            if existing:
                if existing.is_expired:
                    logger.info(f"Session {sid} expired and was reset.")
                    new_session = UserWebSession(sid, timeout_seconds=self.session_ttl)
                    self._sessions[sid] = new_session
                    return new_session
                existing.touch()
                return existing

            new_session = UserWebSession(sid, timeout_seconds=self.session_ttl)
            self._sessions[sid] = new_session
            logger.info(f"Registered new WebSession [id={sid}] (Total active: {len(self._sessions)})")
            return new_session

    def register_reminder(self, reminder_id: str, session_id: str) -> None:
        """Associate a reminder with a specific browser session."""
        with self._lock:
            self._reminder_to_session[reminder_id] = session_id

    def notify_reminder_fired(self, reminder: Reminder) -> None:
        """Route a fired reminder event directly to the scheduling user's session."""
        with self._lock:
            session_id = self._reminder_to_session.get(reminder.id)
            if not session_id:
                logger.warning(f"Reminder {reminder.id} fired but has no associated web session.")
                return

            session = self._sessions.get(session_id)
            if not session:
                return

        event_data = {
            "type": "REMINDER_ALERT",
            "reminder_id": reminder.id,
            "message": reminder.message,
            "speak_text": f"Reminder: {reminder.message}",
            "timestamp": time.time(),
        }
        logger.info(f"Pushing reminder alert to session {session_id}: '{reminder.message}'")
        session.push_event(event_data)

    def cleanup_stale_sessions(self) -> None:
        """Purge inactive expired sessions."""
        with self._lock:
            expired = [sid for sid, s in self._sessions.items() if s.is_expired]
            for sid in expired:
                del self._sessions[sid]
            if expired:
                logger.info(f"Purged {len(expired)} stale web sessions.")
