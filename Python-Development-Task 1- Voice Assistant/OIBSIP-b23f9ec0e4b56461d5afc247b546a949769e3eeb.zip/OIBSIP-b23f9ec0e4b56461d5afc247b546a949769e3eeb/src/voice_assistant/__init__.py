"""Aura Voice Assistant - Production-grade modular Python voice assistant."""

__version__ = "1.0.0"

from voice_assistant.application.app import VoiceAssistantApp
from voice_assistant.config.settings import Settings
from voice_assistant.factory import build_app

__all__ = ["VoiceAssistantApp", "Settings", "build_app", "__version__"]
