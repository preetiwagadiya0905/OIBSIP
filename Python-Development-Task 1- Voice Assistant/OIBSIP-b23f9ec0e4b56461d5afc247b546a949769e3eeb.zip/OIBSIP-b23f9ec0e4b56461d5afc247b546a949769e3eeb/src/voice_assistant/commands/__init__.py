"""Commands package."""

from voice_assistant.commands.base import BaseCommand, CommandContext, CommandResult
from voice_assistant.commands.custom import CustomCommandsCommand
from voice_assistant.commands.datetime import DateTimeCommand
from voice_assistant.commands.email import EmailCommand
from voice_assistant.commands.greeting import GreetingCommand
from voice_assistant.commands.help_exit import CancelCommand, ExitCommand, HelpCommand
from voice_assistant.commands.knowledge import KnowledgeCommand
from voice_assistant.commands.registry import CommandRegistry
from voice_assistant.commands.reminder import ReminderCommand
from voice_assistant.commands.weather import WeatherCommand
from voice_assistant.commands.web_search import WebSearchCommand

__all__ = [
    "BaseCommand",
    "CommandContext",
    "CommandResult",
    "CommandRegistry",
    "GreetingCommand",
    "DateTimeCommand",
    "WebSearchCommand",
    "WeatherCommand",
    "ReminderCommand",
    "EmailCommand",
    "KnowledgeCommand",
    "CustomCommandsCommand",
    "HelpCommand",
    "ExitCommand",
    "CancelCommand",
]
