"""Storage package."""

from voice_assistant.storage.custom_commands import (
    CustomCommandDefinition,
    CustomCommandsStorage,
)

__all__ = ["CustomCommandDefinition", "CustomCommandsStorage"]
