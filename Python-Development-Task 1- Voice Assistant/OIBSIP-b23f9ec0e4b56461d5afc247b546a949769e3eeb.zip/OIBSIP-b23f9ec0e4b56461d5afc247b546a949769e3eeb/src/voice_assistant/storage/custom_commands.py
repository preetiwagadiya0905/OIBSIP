"""Thread-safe persistent storage and validation for custom user commands."""

import json
import threading
from dataclasses import dataclass
from pathlib import Path

from voice_assistant.config.constants import CustomActionType
from voice_assistant.errors.exceptions import SecurityValidationError, StorageError
from voice_assistant.observability.logging import get_logger
from voice_assistant.security.validators import validate_custom_action
from voice_assistant.utils.text import normalize_text

logger = get_logger(__name__)


@dataclass(frozen=True)
class CustomCommandDefinition:
    """Domain model for a user-defined custom command."""
    name: str
    action: CustomActionType
    target: str
    description: str | None = None

    def validate(self) -> None:
        """Validate command parameters against security rules."""
        if not self.name or not self.name.strip():
            raise SecurityValidationError("Command trigger phrase cannot be empty.")
        validate_custom_action(self.action.value, self.target)


class CustomCommandsStorage:
    """JSON file-backed repository for custom commands."""

    def __init__(self, file_path: Path):
        self.file_path = Path(file_path)
        self._lock = threading.Lock()
        self._commands: dict[str, CustomCommandDefinition] = {}
        self.load()

    def load(self) -> None:
        """Load and validate custom commands from disk."""
        with self._lock:
            if not self.file_path.exists() or self.file_path.stat().st_size == 0:
                logger.info(f"Custom commands file '{self.file_path}' is empty or does not exist yet. Initializing empty.")
                self._commands = {}
                return

            try:
                with open(self.file_path, encoding="utf-8") as f:
                    data = json.load(f)

                if not isinstance(data, dict):
                    raise StorageError(f"Custom commands file '{self.file_path}' must be a JSON object.")

                loaded: dict[str, CustomCommandDefinition] = {}
                for name, details in data.items():
                    norm_name = normalize_text(name)
                    if not isinstance(details, dict):
                        continue

                    raw_action = details.get("action", "")
                    target = details.get("target", "")
                    desc = details.get("description")

                    try:
                        action_type = CustomActionType(raw_action)
                        cmd = CustomCommandDefinition(
                            name=norm_name,
                            action=action_type,
                            target=target,
                            description=desc,
                        )
                        cmd.validate()
                        loaded[norm_name] = cmd
                    except (ValueError, SecurityValidationError) as e:
                        logger.warning(f"Skipping invalid custom command '{name}': {e}")

                self._commands = loaded
                logger.info(f"Loaded {len(self._commands)} custom commands from {self.file_path}")

            except json.JSONDecodeError as e:
                logger.error(f"JSON parsing error in custom commands file {self.file_path}: {e}")
                raise StorageError(f"Malformed JSON in custom commands file: {e}") from e
            except Exception as e:
                logger.error(f"Failed to load custom commands: {e}")
                raise StorageError("Could not load custom commands file", details=str(e)) from e

    def save(self) -> None:
        """Persist current commands to disk atomically."""
        with self._lock:
            try:
                self.file_path.parent.mkdir(parents=True, exist_ok=True)
                data = {
                    cmd.name: {
                        "action": cmd.action.value,
                        "target": cmd.target,
                        "description": cmd.description or f"Custom {cmd.action.value} command",
                    }
                    for cmd in self._commands.values()
                }

                temp_path = self.file_path.with_suffix(".tmp")
                with open(temp_path, "w", encoding="utf-8") as f:
                    json.dump(data, f, indent=2)

                # Atomic replace on same filesystem
                temp_path.replace(self.file_path)
                logger.info(f"Successfully saved {len(self._commands)} custom commands to {self.file_path}")
            except Exception as e:
                logger.error(f"Failed to save custom commands to {self.file_path}: {e}")
                raise StorageError("Could not save custom commands file", details=str(e)) from e

    def add_command(
        self,
        name: str,
        action: CustomActionType,
        target: str,
        description: str | None = None,
    ) -> CustomCommandDefinition:
        """Validate, register, and persist a new custom command."""
        norm_name = normalize_text(name)
        cmd = CustomCommandDefinition(
            name=norm_name,
            action=action,
            target=target.strip(),
            description=description,
        )
        cmd.validate()

        with self._lock:
            self._commands[norm_name] = cmd

        self.save()
        logger.info(f"Added custom command '{norm_name}' -> {action.value}:{target}")
        return cmd

    def get_command(self, name: str) -> CustomCommandDefinition | None:
        """Look up a command by trigger phrase."""
        norm_name = normalize_text(name)
        with self._lock:
            return self._commands.get(norm_name)

    def list_commands(self) -> list[CustomCommandDefinition]:
        """Return list of all registered custom commands."""
        with self._lock:
            return list(self._commands.values())

    def delete_command(self, name: str) -> bool:
        """Remove a custom command by trigger phrase."""
        norm_name = normalize_text(name)
        with self._lock:
            if norm_name in self._commands:
                del self._commands[norm_name]
                removed = True
            else:
                removed = False

        if removed:
            self.save()
            logger.info(f"Deleted custom command '{norm_name}'")
        return removed
