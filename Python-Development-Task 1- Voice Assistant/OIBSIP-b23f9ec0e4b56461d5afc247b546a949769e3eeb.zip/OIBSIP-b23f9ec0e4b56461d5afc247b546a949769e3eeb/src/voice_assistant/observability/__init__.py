"""Observability package."""

from voice_assistant.observability.logging import get_logger, setup_logging

__all__ = ["setup_logging", "get_logger"]
