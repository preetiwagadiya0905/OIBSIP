"""Pytest configuration, fixtures, and mock providers."""

import tempfile
from collections.abc import Generator
from pathlib import Path

import pytest

from voice_assistant.audio.listener import MockAudioListener
from voice_assistant.audio.speaker import MockAudioSpeaker
from voice_assistant.config.constants import AppEnvironment
from voice_assistant.config.settings import (
    AudioSettings,
    NLPSettings,
    Settings,
    SMTPSettings,
    StorageSettings,
    WeatherSettings,
)
from voice_assistant.factory import build_app
from voice_assistant.services.email.provider import MockEmailProvider
from voice_assistant.services.knowledge.provider import MockKnowledgeProvider
from voice_assistant.services.weather.provider import MockWeatherProvider


@pytest.fixture
def mock_listener() -> MockAudioListener:
    """Fixture providing a mock audio listener."""
    return MockAudioListener()


@pytest.fixture
def mock_speaker() -> MockAudioSpeaker:
    """Fixture providing a mock audio speaker recording utterances."""
    return MockAudioSpeaker()


@pytest.fixture
def mock_weather_provider() -> MockWeatherProvider:
    """Fixture providing mock weather provider."""
    return MockWeatherProvider()


@pytest.fixture
def mock_email_provider() -> MockEmailProvider:
    """Fixture providing mock email provider."""
    return MockEmailProvider()


@pytest.fixture
def mock_knowledge_provider() -> MockKnowledgeProvider:
    """Fixture providing mock knowledge provider."""
    return MockKnowledgeProvider()


@pytest.fixture
def temp_commands_file() -> Generator[Path, None, None]:
    """Fixture providing a temporary commands.json file."""
    with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as f:
        path = Path(f.name)
    yield path
    if path.exists():
        path.unlink(missing_ok=True)


@pytest.fixture
def test_settings(temp_commands_file: Path) -> Settings:
    """Fixture providing isolated test settings."""
    return Settings(
        app_env=AppEnvironment.TESTING,
        app_name="TestAuraAssistant",
        log_level="DEBUG",
        audio=AudioSettings(tts_rate=180, tts_volume=1.0, speech_timeout=2.0),
        weather=WeatherSettings(api_key="test_weather_key", units="metric"),
        smtp=SMTPSettings(host="smtp.test.com", username="test@test.com", password="pwd"),
        nlp=NLPSettings(confidence_threshold=0.50),
        storage=StorageSettings(commands_path=temp_commands_file),
    )


@pytest.fixture
def test_app(
    test_settings: Settings,
    mock_listener: MockAudioListener,
    mock_speaker: MockAudioSpeaker,
    mock_weather_provider: MockWeatherProvider,
    mock_email_provider: MockEmailProvider,
    mock_knowledge_provider: MockKnowledgeProvider,
) -> Generator:
    """Fixture providing a fully wired test application instance with mocked I/O and services."""
    app = build_app(
        settings=test_settings,
        override_listener=mock_listener,
        override_speaker=mock_speaker,
        override_weather_provider=mock_weather_provider,
        override_email_provider=mock_email_provider,
        override_knowledge_provider=mock_knowledge_provider,
    )
    yield app
    app.shutdown()
