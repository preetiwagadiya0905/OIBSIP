"""Integration tests verifying full Acceptance Test Checklist scenarios."""

from unittest.mock import patch

from voice_assistant.application.app import VoiceAssistantApp
from voice_assistant.config.constants import AppState


def test_acceptance_greeting(test_app: VoiceAssistantApp):
    """Acceptance Test 1: Greeting."""
    res = test_app.process_utterance("Hello")
    assert res.success
    assert any(g in res.response_text for g in ["Good morning", "Good afternoon", "Good evening", "Hello"])


def test_acceptance_time(test_app: VoiceAssistantApp):
    """Acceptance Test 2: Time."""
    res = test_app.process_utterance("What time is it?")
    assert res.success
    assert "current time is" in res.response_text.lower()


def test_acceptance_date(test_app: VoiceAssistantApp):
    """Acceptance Test 3: Date."""
    res = test_app.process_utterance("What's today's date?")
    assert res.success
    assert "today is" in res.response_text.lower()


@patch("webbrowser.open_new_tab")
def test_acceptance_search(mock_open, test_app: VoiceAssistantApp):
    """Acceptance Test 4: Search."""
    res = test_app.process_utterance("Search the web for Python decorators.")
    assert res.success
    assert "searching the web for python decorators" in res.response_text.lower()
    mock_open.assert_called_once()


def test_acceptance_weather(test_app: VoiceAssistantApp):
    """Acceptance Test 5: Weather."""
    res = test_app.process_utterance("What's the weather in Hyderabad?")
    assert res.success
    assert "Hyderabad" in res.response_text
    assert "29 degrees Celsius" in res.response_text


def test_acceptance_reminder(test_app: VoiceAssistantApp):
    """Acceptance Test 6: Reminder."""
    res = test_app.process_utterance("Remind me in 10 seconds to test the assistant.")
    assert res.success
    assert "10 seconds" in res.response_text
    assert "test the assistant" in res.response_text
    assert len(test_app.reminder_scheduler.list_active()) == 1


def test_acceptance_knowledge(test_app: VoiceAssistantApp):
    """Acceptance Test 7: Knowledge QA."""
    res = test_app.process_utterance("Who was Alan Turing?")
    assert res.success
    assert "alan turing" in res.response_text.lower() or "computer scientist" in res.response_text.lower()


def test_acceptance_custom_commands(test_app: VoiceAssistantApp):
    """Acceptance Test 8: Add and execute custom command."""
    # 1. Add custom command
    res1 = test_app.process_utterance(
        "create a command called open python that opens https://python.org"
    )
    assert res1.success
    assert "created successfully" in res1.response_text

    # 2. Trigger custom command
    with patch("webbrowser.open_new_tab") as mock_open:
        res2 = test_app.process_utterance("open python")
        assert res2.success
        assert "Opening open python" in res2.response_text
        mock_open.assert_called_once_with("https://python.org")


def test_acceptance_unknown_command(test_app: VoiceAssistantApp):
    """Acceptance Test 9: Unknown / Unrecognized speech input."""
    res = test_app.process_utterance("asdfghjkl")
    assert not res.success
    assert "try saying 'help'" in res.response_text.lower()


def test_acceptance_cancellation(test_app: VoiceAssistantApp):
    """Acceptance Test 10: Cancellation."""
    res = test_app.process_utterance("cancel")
    assert res.success
    assert "cancelled" in res.response_text.lower() or "nothing" in res.response_text.lower()


def test_acceptance_exit(test_app: VoiceAssistantApp):
    """Acceptance Test 11: Exit."""
    res = test_app.process_utterance("goodbye")
    assert res.success
    assert res.should_exit is True
    assert "goodbye" in res.response_text.lower()
    assert test_app.state == AppState.SHUTTING_DOWN
