"""Integration tests for web assistant end-to-end multi-turn conversational flows."""

from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from voice_assistant.config.constants import AppEnvironment
from voice_assistant.config.settings import Settings, WebSettings
from voice_assistant.services.email.provider import EmailService, MockEmailProvider
from voice_assistant.web.app import create_app


@pytest.fixture
def mock_email_service() -> EmailService:
    return EmailService(MockEmailProvider())


@pytest.fixture
def web_app_client(temp_commands_file: Path, mock_email_service: EmailService) -> TestClient:
    settings = Settings(
        app_env=AppEnvironment.TESTING,
        web=WebSettings(rate_limit_per_minute=200),
    )
    app = create_app(
        settings=settings,
        custom_email_service=mock_email_service,
    )
    return TestClient(app)


def test_web_multi_turn_email_flow_complete(web_app_client: TestClient):
    """Test full multi-turn conversational email flow across HTTP POST requests."""
    sid = "browser_client_101"

    # Step 1: Initiate
    r1 = web_app_client.post("/api/assistant", json={"message": "send an email", "session_id": sid})
    assert r1.status_code == 200
    assert "Who should I send the email to" in r1.json()["response"]
    assert r1.json()["in_conversation"] is True

    # Step 2: Recipient
    r2 = web_app_client.post("/api/assistant", json={"message": "dev@company.com", "session_id": sid})
    assert r2.status_code == 200
    assert "What should the subject be" in r2.json()["response"]
    assert r2.json()["in_conversation"] is True

    # Step 3: Subject
    r3 = web_app_client.post("/api/assistant", json={"message": "Deployment Successful", "session_id": sid})
    assert r3.status_code == 200
    assert "What should the message say" in r3.json()["response"]
    assert r3.json()["in_conversation"] is True

    # Step 4: Body
    r4 = web_app_client.post("/api/assistant", json={"message": "Version 1.0 is live on production.", "session_id": sid})
    assert r4.status_code == 200
    assert "You're about to send an email to dev@company.com" in r4.json()["response"]
    assert "Should I send it" in r4.json()["response"]

    # Step 5: Confirmation
    r5 = web_app_client.post("/api/assistant", json={"message": "yes", "session_id": sid})
    assert r5.status_code == 200
    assert "Email sent successfully to dev@company.com" in r5.json()["response"]
    assert r5.json()["in_conversation"] is False


def test_web_multi_turn_email_cancellation(web_app_client: TestClient):
    """Test cancelling ongoing web conversational flow."""
    sid = "browser_client_102"

    web_app_client.post("/api/assistant", json={"message": "send an email", "session_id": sid})
    web_app_client.post("/api/assistant", json={"message": "dev@company.com", "session_id": sid})

    # Cancel
    cancel_res = web_app_client.post("/api/assistant", json={"message": "cancel", "session_id": sid})
    assert cancel_res.status_code == 200
    assert "cancelled" in cancel_res.json()["response"].lower()
    assert cancel_res.json()["in_conversation"] is False
