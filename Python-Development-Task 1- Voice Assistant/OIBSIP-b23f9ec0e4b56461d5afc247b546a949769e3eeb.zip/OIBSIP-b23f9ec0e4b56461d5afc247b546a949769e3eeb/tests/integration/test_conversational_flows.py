"""Integration tests for multi-turn conversational workflows and state machine."""


from voice_assistant.application.app import VoiceAssistantApp
from voice_assistant.audio.speaker import MockAudioSpeaker
from voice_assistant.services.email.provider import MockEmailProvider


def test_multi_turn_email_flow_complete(test_app: VoiceAssistantApp, mock_speaker: MockAudioSpeaker, mock_email_provider: MockEmailProvider):
    """Test full multi-turn email composition:

    User: 'send an email'
    Assistant: 'Who should I send the email to?'
    User: 'test@example.com'
    Assistant: 'What should the subject be?'
    User: 'Quarterly Report'
    Assistant: 'What should the message say?'
    User: 'The report is ready.'
    Assistant: 'You're about to send an email to test@example.com with subject 'Quarterly Report'. Should I send it?'
    User: 'Yes'
    Assistant: 'Email sent successfully to test@example.com.'
    """
    # 1. Initiate email flow
    r1 = test_app.process_utterance("send an email")
    assert "Who should I send the email to" in r1.response_text
    assert test_app.session_manager.has_active_session

    # 2. Provide recipient
    r2 = test_app.process_utterance("test@example.com")
    assert "What should the subject be" in r2.response_text

    # 3. Provide subject
    r3 = test_app.process_utterance("Quarterly Report")
    assert "What should the message say" in r3.response_text

    # 4. Provide body
    r4 = test_app.process_utterance("The report is ready.")
    assert "You're about to send an email to test@example.com" in r4.response_text
    assert "Should I send it" in r4.response_text

    # 5. Confirm sending
    r5 = test_app.process_utterance("Yes")
    assert "Email sent successfully" in r5.response_text
    assert not test_app.session_manager.has_active_session
    assert len(mock_email_provider.sent_emails) == 1
    assert mock_email_provider.sent_emails[0].recipient == "test@example.com"
    assert mock_email_provider.sent_emails[0].subject == "Quarterly Report"
    assert mock_email_provider.sent_emails[0].body == "The report is ready."


def test_multi_turn_email_cancellation(test_app: VoiceAssistantApp, mock_email_provider: MockEmailProvider):
    """Test cancelling an ongoing multi-turn email session."""
    test_app.process_utterance("send an email")
    assert test_app.session_manager.has_active_session

    test_app.process_utterance("user@example.com")
    test_app.process_utterance("Meeting")
    test_app.process_utterance("See you tomorrow")

    # Reject on confirmation
    cancel_res = test_app.process_utterance("No")
    assert "cancelled" in cancel_res.response_text.lower()
    assert not test_app.session_manager.has_active_session
    assert len(mock_email_provider.sent_emails) == 0


def test_direct_single_turn_email_flow(test_app: VoiceAssistantApp, mock_email_provider: MockEmailProvider):
    """Test email command with all entities provided upfront."""
    r1 = test_app.process_utterance(
        "send email to client@example.com with subject Deployment and body Completed successfully"
    )
    assert "You're about to send an email to client@example.com" in r1.response_text

    r2 = test_app.process_utterance("Confirm")
    assert "Email sent successfully" in r2.response_text
    assert len(mock_email_provider.sent_emails) == 1
