"""Unit tests for Natural Language Understanding, Intent Classification, and Entity Extraction."""

import pytest

from voice_assistant.config.constants import CustomActionType, IntentType
from voice_assistant.nlp.classifier import HybridIntentClassifier
from voice_assistant.nlp.entities import (
    extract_custom_command_entity,
    extract_email_entity,
    extract_knowledge_entity,
    extract_reminder_entity,
    extract_search_entity,
    extract_weather_entity,
)
from voice_assistant.nlp.parser import NLUParser


@pytest.fixture
def parser() -> NLUParser:
    classifier = HybridIntentClassifier(confidence_threshold=0.50)
    return NLUParser(classifier=classifier, confidence_threshold=0.50)


@pytest.mark.parametrize("query, expected_intent", [
    ("hello", IntentType.GREETING),
    ("good morning assistant", IntentType.GREETING),
    ("what time is it", IntentType.TIME),
    ("tell me the time", IntentType.TIME),
    ("what is today's date", IntentType.DATE),
    ("what day is it", IntentType.DATE),
    ("what's the weather in hyderabad", IntentType.WEATHER),
    ("how is the weather in london", IntentType.WEATHER),
    ("remind me in 10 minutes to call john", IntentType.SET_REMINDER),
    ("set a reminder for 30 seconds to check code", IntentType.SET_REMINDER),
    ("send an email to test@example.com", IntentType.SEND_EMAIL),
    ("search the web for python tutorials", IntentType.WEB_SEARCH),
    ("google quantum computing", IntentType.WEB_SEARCH),
    ("who was alan turing", IntentType.KNOWLEDGE),
    ("what is photosynthesis", IntentType.KNOWLEDGE),
    ("create a command called open github that opens https://github.com", IntentType.ADD_COMMAND),
    ("help", IntentType.HELP),
    ("what can you do", IntentType.HELP),
    ("goodbye", IntentType.EXIT),
    ("exit", IntentType.EXIT),
    ("yes", IntentType.CONFIRMATION_YES),
    ("confirm", IntentType.CONFIRMATION_YES),
    ("no", IntentType.CONFIRMATION_NO),
    ("cancel", IntentType.CANCEL),
])
def test_intent_classification(parser: NLUParser, query: str, expected_intent: IntentType):
    """Test intent classification accuracy across core commands."""
    res = parser.parse(query)
    assert res.intent == expected_intent
    assert res.confidence >= 0.50


def test_extract_weather_entity():
    """Test location entity extraction from weather queries."""
    w1 = extract_weather_entity("what is the weather like in Hyderabad")
    assert w1 is not None
    assert w1.location.lower() == "hyderabad"

    w2 = extract_weather_entity("temperature in New York please")
    assert w2 is not None
    assert w2.location.lower() == "new york"


def test_extract_reminder_entity():
    """Test duration and task extraction from reminder queries."""
    r1 = extract_reminder_entity("remind me in 10 minutes to call John")
    assert r1 is not None
    assert r1.duration_seconds == 600
    assert r1.message.lower() == "call john"

    r2 = extract_reminder_entity("set a reminder for 30 seconds to test assistant")
    assert r2 is not None
    assert r2.duration_seconds == 30
    assert r2.message.lower() == "test assistant"

    r3 = extract_reminder_entity("remind me after two hours to take medicine")
    assert r3 is not None
    assert r3.duration_seconds == 7200
    assert r3.message.lower() == "take medicine"


def test_extract_email_entity():
    """Test single-sentence email entity extraction."""
    e1 = extract_email_entity("send email to test@example.com with subject meeting and body see you tomorrow")
    assert e1.recipient == "test@example.com"
    assert e1.subject == "meeting"
    assert e1.body == "see you tomorrow"


def test_extract_search_entity():
    """Test web search query extraction."""
    s1 = extract_search_entity("search the web for Python async programming")
    assert s1 is not None
    assert s1.query == "python async programming"

    s2 = extract_search_entity("look up FastAPI documentation please")
    assert s2 is not None
    assert s2.query == "fastapi documentation"


def test_extract_knowledge_entity():
    """Test question topic extraction."""
    k1 = extract_knowledge_entity("who was Alan Turing")
    assert k1 is not None
    assert k1.query == "alan turing"

    k2 = extract_knowledge_entity("what is the capital of Japan")
    assert k2 is not None
    assert k2.query == "the capital of japan"


def test_extract_custom_command_entity():
    """Test custom command creation entity extraction."""
    c1 = extract_custom_command_entity("create a command called open github that opens https://github.com")
    assert c1 is not None
    assert c1.name == "open github"
    assert c1.action == CustomActionType.OPEN_URL
    assert c1.target == "https://github.com"

    c2 = extract_custom_command_entity("add command greet me that speaks hello friend")
    assert c2 is not None
    assert c2.name == "greet me"
    assert c2.action == CustomActionType.SPEAK
    assert c2.target == "hello friend"


def test_unknown_query_handling(parser: NLUParser):
    """Test that gibberish input produces UNKNOWN intent."""
    res = parser.parse("asdfghjklqwerty12345")
    assert res.intent == IntentType.UNKNOWN
    assert not res.is_confident
