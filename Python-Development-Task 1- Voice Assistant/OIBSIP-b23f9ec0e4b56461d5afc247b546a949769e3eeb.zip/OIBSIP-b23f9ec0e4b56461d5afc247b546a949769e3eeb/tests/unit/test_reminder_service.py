"""Unit tests for reminder scheduler and timing execution."""

import time

import pytest

from voice_assistant.config.constants import ReminderStatus
from voice_assistant.errors.exceptions import ReminderError
from voice_assistant.services.reminders.models import Reminder
from voice_assistant.services.reminders.scheduler import ReminderScheduler


def test_reminder_human_duration_formatting():
    """Test human readable duration formatting."""
    r1 = Reminder(duration_seconds=30, message="Test")
    assert r1.human_duration == "30 seconds"

    r2 = Reminder(duration_seconds=60, message="Test")
    assert r2.human_duration == "1 minute"

    r3 = Reminder(duration_seconds=600, message="Test")
    assert r3.human_duration == "10 minutes"

    r4 = Reminder(duration_seconds=3660, message="Test")
    assert r4.human_duration == "1 hours and 1 minutes"


def test_reminder_bounds_validation():
    """Test scheduler rejects unreasonable or invalid durations."""
    scheduler = ReminderScheduler()
    try:
        with pytest.raises(ReminderError):
            scheduler.schedule(duration_seconds=0, message="Instant")

        with pytest.raises(ReminderError):
            scheduler.schedule(duration_seconds=86400 * 40, message="Too far in future")
    finally:
        scheduler.shutdown()


def test_reminder_scheduling_and_trigger():
    """Test asynchronous timer callback execution."""
    fired_reminders = []

    def alert_callback(rem: Reminder):
        fired_reminders.append(rem)

    scheduler = ReminderScheduler(alert_callback=alert_callback)
    try:
        # Schedule short 0.1s reminder (100ms) for test speed
        rem = scheduler.schedule(duration_seconds=1, message="Quick test")
        assert rem.status == ReminderStatus.SCHEDULED
        assert len(scheduler.list_active()) == 1

        # Wait for timer to fire
        time.sleep(1.2)

        assert len(fired_reminders) == 1
        assert fired_reminders[0].message == "Quick test"
        assert fired_reminders[0].status == ReminderStatus.COMPLETED
        assert len(scheduler.list_active()) == 0
    finally:
        scheduler.shutdown()


def test_reminder_cancellation():
    """Test cancelling active reminder."""
    scheduler = ReminderScheduler()
    try:
        rem = scheduler.schedule(duration_seconds=100, message="Cancel me")
        assert len(scheduler.list_active()) == 1

        cancelled = scheduler.cancel(rem.id)
        assert cancelled is True
        assert rem.status == ReminderStatus.CANCELLED
        assert len(scheduler.list_active()) == 0
    finally:
        scheduler.shutdown()
