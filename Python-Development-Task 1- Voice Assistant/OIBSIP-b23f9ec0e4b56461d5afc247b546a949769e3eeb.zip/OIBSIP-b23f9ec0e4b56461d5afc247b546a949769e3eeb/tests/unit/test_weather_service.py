"""Unit tests for weather service, geocoding, and client error handling."""

from unittest.mock import MagicMock, patch

import pytest
import requests

from voice_assistant.config.settings import WeatherSettings
from voice_assistant.errors.exceptions import WeatherServiceError
from voice_assistant.services.weather.client import OpenWeatherMapClient
from voice_assistant.services.weather.geocoder import GeoCoordinates, OpenWeatherMapGeocoder
from voice_assistant.services.weather.models import WeatherData
from voice_assistant.services.weather.provider import (
    MockWeatherProvider,
    WeatherService,
)


@pytest.fixture
def mock_geocoder():
    geocoder = MagicMock(spec=OpenWeatherMapGeocoder)
    geocoder.geocode.return_value = GeoCoordinates(
        latitude=17.3850,
        longitude=78.4867,
        name="Hyderabad",
        country="IN",
    )
    return geocoder


def test_weather_data_speech_formatting():
    """Test natural language speech output generation."""
    data = WeatherData(
        location="Hyderabad",
        temperature_celsius=29.4,
        feels_like_celsius=31.2,
        humidity=72,
        description="Partly cloudy",
        wind_speed=3.5,
        country="IN",
    )
    text = data.to_speech_text()
    assert "Hyderabad, IN" in text
    assert "29 degrees Celsius" in text
    assert "feels like 31 degrees" in text
    assert "partly cloudy" in text
    assert "72 percent" in text


@patch("requests.get")
def test_geocoder_success(mock_get):
    """Test successful geocoding query."""
    mock_resp = MagicMock()
    mock_resp.status_code = 200
    mock_resp.json.return_value = [
        {"name": "Hyderabad", "lat": 17.3850, "lon": 78.4867, "country": "IN"}
    ]
    mock_get.return_value = mock_resp

    geocoder = OpenWeatherMapGeocoder(api_key="valid_key")
    coords = geocoder.geocode("Hyderabad")
    assert coords.name == "Hyderabad"
    assert coords.latitude == 17.3850
    assert coords.longitude == 78.4867
    assert coords.country == "IN"


@patch("requests.get")
def test_geocoder_city_not_found(mock_get):
    """Test geocoder raises WeatherServiceError on empty list."""
    mock_resp = MagicMock()
    mock_resp.status_code = 200
    mock_resp.json.return_value = []
    mock_get.return_value = mock_resp

    geocoder = OpenWeatherMapGeocoder(api_key="valid_key")
    with pytest.raises(WeatherServiceError, match="couldn't find coordinates"):
        geocoder.geocode("NonExistentCityXYZ")


@patch("requests.get")
def test_weather_client_success(mock_get, mock_geocoder):
    """Test successful current weather fetch and domain mapping."""
    mock_resp = MagicMock()
    mock_resp.status_code = 200
    mock_resp.json.return_value = {
        "name": "Hyderabad",
        "sys": {"country": "IN"},
        "main": {"temp": 29.0, "feels_like": 31.0, "humidity": 72},
        "weather": [{"description": "partly cloudy"}],
        "wind": {"speed": 3.5},
    }
    mock_get.return_value = mock_resp

    settings = WeatherSettings(api_key="valid_key", units="metric")
    client = OpenWeatherMapClient(settings=settings, geocoder=mock_geocoder)
    result = client.fetch_weather("Hyderabad")

    assert result.location == "Hyderabad"
    assert result.temperature_celsius == 29.0
    assert result.humidity == 72
    assert result.description == "Partly cloudy"


@patch("requests.get")
def test_weather_client_timeout(mock_get, mock_geocoder):
    """Test timeout handling in weather client."""
    mock_get.side_effect = requests.Timeout("Connection timed out")

    settings = WeatherSettings(api_key="valid_key")
    client = OpenWeatherMapClient(settings=settings, geocoder=mock_geocoder)

    with pytest.raises(WeatherServiceError, match="timed out"):
        client.fetch_weather("Hyderabad")


def test_mock_weather_provider():
    """Test fallback mock weather provider."""
    provider = MockWeatherProvider()
    service = WeatherService(provider)
    data = service.get_weather("Hyderabad")
    assert data.location == "Hyderabad"
    assert data.temperature_celsius == 29.0
