"""Unit tests for individual command handlers."""

from unittest.mock import patch

from voice_assistant.commands.base import CommandContext
from voice_assistant.commands.datetime import DateTimeCommand
from voice_assistant.commands.greeting import GreetingCommand
from voice_assistant.commands.help_exit import ExitCommand, HelpCommand
from voice_assistant.commands.reminder import ReminderCommand
from voice_assistant.commands.weather import WeatherCommand
from voice_assistant.commands.web_search import WebSearchCommand
from voice_assistant.config.constants import IntentType
from voice_assistant.nlp.intent import IntentResult
from voice_assistant.services.reminders.scheduler import ReminderScheduler
from voice_assistant.services.weather.provider import WeatherService


def test_greeting_command():
    cmd = GreetingCommand()
    intent = IntentResult(
        intent=IntentType.GREETING,
        confidence=1.0,
        raw_text="hello",
        normalized_text="hello",
    )
    result = cmd.execute(intent, CommandContext())
    assert result.success
    assert "Aura" in result.response_text


def test_datetime_command_time_and_date():
    cmd = DateTimeCommand()

    time_intent = IntentResult(
        intent=IntentType.TIME,
        confidence=1.0,
        raw_text="what time is it",
        normalized_text="what time is it",
    )
    time_res = cmd.execute(time_intent, CommandContext())
    assert time_res.success
    assert "current time is" in time_res.response_text.lower()

    date_intent = IntentResult(
        intent=IntentType.DATE,
        confidence=1.0,
        raw_text="what is today's date",
        normalized_text="what is today's date",
    )
    date_res = cmd.execute(date_intent, CommandContext())
    assert date_res.success
    assert "today is" in date_res.response_text.lower()


@patch("webbrowser.open_new_tab")
def test_web_search_command(mock_open):
    cmd = WebSearchCommand()
    intent = IntentResult(
        intent=IntentType.WEB_SEARCH,
        confidence=0.95,
        raw_text="search the web for python decorators",
        normalized_text="search the web for python decorators",
        entities={"query": "python decorators"},
    )
    result = cmd.execute(intent, CommandContext())
    assert result.success
    assert "Searching the web for python decorators" in result.response_text
    mock_open.assert_called_once()
    assert "google.com/search?q=python+decorators" in mock_open.call_args[0][0]


def test_weather_command(mock_weather_provider):
    service = WeatherService(mock_weather_provider)
    cmd = WeatherCommand(service)
    intent = IntentResult(
        intent=IntentType.WEATHER,
        confidence=0.95,
        raw_text="weather in Hyderabad",
        normalized_text="weather in hyderabad",
        entities={"location": "Hyderabad"},
    )
    result = cmd.execute(intent, CommandContext())
    assert result.success
    assert "Hyderabad" in result.response_text
    assert "29 degrees Celsius" in result.response_text


def test_reminder_command():
    scheduler = ReminderScheduler()
    try:
        cmd = ReminderCommand(scheduler)
        intent = IntentResult(
            intent=IntentType.SET_REMINDER,
            confidence=0.95,
            raw_text="remind me in 10 seconds to check code",
            normalized_text="remind me in 10 seconds to check code",
            entities={"duration_seconds": 10, "message": "check code"},
        )
        result = cmd.execute(intent, CommandContext())
        assert result.success
        assert "10 seconds" in result.response_text
        assert "check code" in result.response_text
    finally:
        scheduler.shutdown()


def test_help_and_exit_commands():
    help_cmd = HelpCommand()
    help_res = help_cmd.execute(
        IntentResult(intent=IntentType.HELP, confidence=1.0, raw_text="help", normalized_text="help"),
        CommandContext(),
    )
    assert help_res.success
    assert "weather" in help_res.response_text.lower()
    assert "email" in help_res.response_text.lower()

    exit_cmd = ExitCommand()
    exit_res = exit_cmd.execute(
        IntentResult(intent=IntentType.EXIT, confidence=1.0, raw_text="bye", normalized_text="bye"),
        CommandContext(),
    )
    assert exit_res.success
    assert exit_res.should_exit is True
    assert "Goodbye" in exit_res.response_text
