"""Unit tests for configuration and settings loading."""

import pytest

from voice_assistant.config.constants import AppEnvironment
from voice_assistant.config.settings import Settings
from voice_assistant.errors.exceptions import ConfigurationError


def test_default_settings_loading(monkeypatch: pytest.MonkeyPatch):
    """Test loading settings with standard defaults when no env vars are set."""
    monkeypatch.delenv("OPENWEATHER_API_KEY", raising=False)
    monkeypatch.delenv("SMTP_USERNAME", raising=False)
    monkeypatch.delenv("SMTP_PASSWORD", raising=False)

    settings = Settings.load()
    assert settings.app_name == "Aura Voice Assistant"
    assert settings.audio.tts_rate == 175
    assert settings.audio.tts_volume == 1.0
    assert settings.weather.units == "metric"
    assert not settings.weather.is_configured
    assert not settings.smtp.is_configured


def test_environment_variables_override(monkeypatch: pytest.MonkeyPatch):
    """Test environment variable overrides."""
    monkeypatch.setenv("APP_ENV", "production")
    monkeypatch.setenv("APP_NAME", "CustomAssistant")
    monkeypatch.setenv("TTS_RATE", "200")
    monkeypatch.setenv("TTS_VOLUME", "0.8")
    monkeypatch.setenv("OPENWEATHER_API_KEY", "real_key_123")
    monkeypatch.setenv("SMTP_HOST", "smtp.myhost.com")
    monkeypatch.setenv("SMTP_USERNAME", "admin@myhost.com")
    monkeypatch.setenv("SMTP_PASSWORD", "secret123")

    settings = Settings.load()
    assert settings.app_env == AppEnvironment.PRODUCTION
    assert settings.app_name == "CustomAssistant"
    assert settings.audio.tts_rate == 200
    assert settings.audio.tts_volume == 0.8
    assert settings.weather.api_key == "real_key_123"
    assert settings.weather.is_configured
    assert settings.smtp.is_configured
    assert settings.smtp.host == "smtp.myhost.com"


def test_invalid_tts_rate_boundary(monkeypatch: pytest.MonkeyPatch):
    """Test that out-of-bounds TTS rate raises ConfigurationError."""
    monkeypatch.setenv("TTS_RATE", "999")
    with pytest.raises(ConfigurationError):
        Settings.load()


def test_invalid_tts_volume_boundary(monkeypatch: pytest.MonkeyPatch):
    """Test that out-of-bounds TTS volume raises ConfigurationError."""
    monkeypatch.setenv("TTS_VOLUME", "2.5")
    with pytest.raises(ConfigurationError):
        Settings.load()


def test_invalid_nlp_threshold_boundary(monkeypatch: pytest.MonkeyPatch):
    """Test that out-of-bounds NLP threshold raises ConfigurationError."""
    monkeypatch.setenv("NLP_CONFIDENCE_THRESHOLD", "1.5")
    with pytest.raises(ConfigurationError):
        Settings.load()
