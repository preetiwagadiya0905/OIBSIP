"""Unit tests for email service, SMTP client, and error handling."""

import smtplib
from unittest.mock import MagicMock, patch

import pytest

from voice_assistant.config.settings import SMTPSettings
from voice_assistant.errors.exceptions import EmailServiceError, SecurityValidationError
from voice_assistant.services.email.client import SMTPEmailClient
from voice_assistant.services.email.models import EmailMessageData
from voice_assistant.services.email.provider import (
    EmailService,
    MockEmailProvider,
    SMTPEmailProvider,
)


def test_email_message_data_validation():
    """Test domain model validation."""
    valid = EmailMessageData(
        recipient="user@example.com",
        subject="Project Status",
        body="All systems go.",
    )
    valid.validate()

    # Invalid recipient
    invalid_email = EmailMessageData(recipient="bad_email", subject="Hi", body="Test")
    with pytest.raises(SecurityValidationError):
        invalid_email.validate()

    # Empty subject
    empty_subj = EmailMessageData(recipient="user@example.com", subject="", body="Test")
    with pytest.raises(ValueError, match="subject"):
        empty_subj.validate()

    # Empty body
    empty_body = EmailMessageData(recipient="user@example.com", subject="Hi", body="")
    with pytest.raises(ValueError, match="body"):
        empty_body.validate()


def test_mock_email_provider():
    """Test MockEmailProvider execution and recording."""
    provider = MockEmailProvider()
    service = EmailService(provider)

    res = service.send(
        recipient="test@example.com",
        subject="Hello",
        body="Testing mock email dispatch",
    )
    assert res.success
    assert len(provider.sent_emails) == 1
    assert provider.sent_emails[0].recipient == "test@example.com"


@patch("smtplib.SMTP")
def test_smtp_client_success(mock_smtp_class):
    """Test SMTP client transmission with STARTTLS and login."""
    mock_server = MagicMock()
    mock_smtp_class.return_value = mock_server

    settings = SMTPSettings(
        host="smtp.example.com",
        port=587,
        username="user@example.com",
        password="secret_password",
        use_tls=True,
    )
    client = SMTPEmailClient(settings)
    provider = SMTPEmailProvider(client)
    service = EmailService(provider)

    result = service.send(
        recipient="client@domain.com",
        subject="Invoice #101",
        body="Please find invoice attached.",
    )
    assert result.success
    mock_server.starttls.assert_called_once()
    mock_server.login.assert_called_once_with("user@example.com", "secret_password")
    mock_server.send_message.assert_called_once()


@patch("smtplib.SMTP")
def test_smtp_authentication_failure(mock_smtp_class):
    """Test SMTP auth failure error translation."""
    mock_server = MagicMock()
    mock_server.login.side_effect = smtplib.SMTPAuthenticationError(535, b"Auth failed")
    mock_smtp_class.return_value = mock_server

    settings = SMTPSettings(
        host="smtp.example.com",
        username="user@example.com",
        password="wrong_password",
    )
    client = SMTPEmailClient(settings)
    provider = SMTPEmailProvider(client)
    service = EmailService(provider)

    with pytest.raises(EmailServiceError, match="authentication failed"):
        service.send(
            recipient="test@example.com",
            subject="Test",
            body="Hello",
        )
