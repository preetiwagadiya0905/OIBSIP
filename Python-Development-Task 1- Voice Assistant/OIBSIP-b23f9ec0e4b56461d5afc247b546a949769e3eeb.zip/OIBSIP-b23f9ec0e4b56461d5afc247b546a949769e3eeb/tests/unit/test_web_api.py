"""Unit tests for FastAPI Web API endpoints, rate limiting, and session isolation."""

from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from voice_assistant.config.constants import AppEnvironment
from voice_assistant.config.settings import (
    AudioSettings,
    NLPSettings,
    Settings,
    SMTPSettings,
    StorageSettings,
    WeatherSettings,
    WebSettings,
)
from voice_assistant.services.weather.provider import MockWeatherProvider, WeatherService
from voice_assistant.web.app import create_app


@pytest.fixture
def web_test_settings(temp_commands_file: Path) -> Settings:
    return Settings(
        app_env=AppEnvironment.TESTING,
        app_name="Aura Web Test",
        log_level="DEBUG",
        audio=AudioSettings(),
        weather=WeatherSettings(api_key="test_key", units="metric"),
        smtp=SMTPSettings(),
        nlp=NLPSettings(confidence_threshold=0.50),
        storage=StorageSettings(commands_path=temp_commands_file),
        web=WebSettings(rate_limit_per_minute=100, cors_origins=["*"]),
    )


@pytest.fixture
def client(web_test_settings: Settings) -> TestClient:
    app = create_app(
        settings=web_test_settings,
        custom_weather_service=WeatherService(MockWeatherProvider()),
    )
    return TestClient(app)


def test_health_endpoint(client: TestClient):
    """Test /api/health endpoint."""
    response = client.get("/api/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "healthy"
    assert data["app_name"] == "Aura Web Test"


def test_config_endpoint(client: TestClient):
    """Test /api/config public configuration endpoint."""
    response = client.get("/api/config")
    assert response.status_code == 200
    data = response.json()
    assert "weather_enabled" in data
    assert "email_enabled" in data
    assert data["version"] == "1.0.0"


def test_assistant_greeting(client: TestClient):
    """Test greeting command via Web API."""
    response = client.post("/api/assistant", json={"message": "hello", "session_id": "test_session_1"})
    assert response.status_code == 200
    data = response.json()
    assert data["success"] is True
    assert data["intent"] == "GREETING"
    assert "Aura" in data["response"]
    assert data["session_id"] == "test_session_1"


def test_assistant_time_and_date(client: TestClient):
    """Test time and date commands via Web API."""
    # Time
    r1 = client.post("/api/assistant", json={"message": "what time is it"})
    assert r1.status_code == 200
    assert r1.json()["intent"] == "TIME"
    assert "current time is" in r1.json()["response"].lower()

    # Date
    r2 = client.post("/api/assistant", json={"message": "what is today's date"})
    assert r2.status_code == 200
    assert r2.json()["intent"] == "DATE"
    assert "today is" in r2.json()["response"].lower()


def test_assistant_web_search(client: TestClient):
    """Test web search returns safe URL in action metadata."""
    response = client.post("/api/assistant", json={"message": "search the web for Python decorators"})
    assert response.status_code == 200
    data = response.json()
    assert data["intent"] == "WEB_SEARCH"
    assert data["action"] == "OPEN_URL"
    assert "python+decorators" in data["data"]["url"].lower()


def test_assistant_weather(client: TestClient):
    """Test weather query over Web API."""
    response = client.post("/api/assistant", json={"message": "what is the weather in Hyderabad"})
    assert response.status_code == 200
    data = response.json()
    assert data["intent"] == "WEATHER"
    assert "Hyderabad" in data["response"]
    assert "29 degrees Celsius" in data["response"]


def test_assistant_reminder_and_listing(client: TestClient):
    """Test scheduling and listing reminders."""
    # Schedule via conversational command
    r1 = client.post("/api/assistant", json={
        "message": "remind me in 30 seconds to check deployment",
        "session_id": "user_a",
    })
    assert r1.status_code == 200
    data1 = r1.json()
    assert data1["intent"] == "SET_REMINDER"
    assert "30 seconds" in data1["response"]

    # List active reminders
    r2 = client.get("/api/reminders")
    assert r2.status_code == 200
    data2 = r2.json()
    assert data2["success"] is True
    assert len(data2["reminders"]) >= 1
    assert any("check deployment" in r["message"] for r in data2["reminders"])


def test_multi_user_session_isolation(client: TestClient):
    """Test User A and User B maintain isolated conversational states."""
    # User A starts email session
    r_a1 = client.post("/api/assistant", json={"message": "send an email", "session_id": "user_alpha"})
    assert "Who should I send the email to" in r_a1.json()["response"]
    assert r_a1.json()["in_conversation"] is True

    # User B asks for time independently
    r_b1 = client.post("/api/assistant", json={"message": "what time is it", "session_id": "user_beta"})
    assert r_b1.json()["intent"] == "TIME"
    assert r_b1.json()["in_conversation"] is False

    # User A provides recipient
    r_a2 = client.post("/api/assistant", json={"message": "boss@example.com", "session_id": "user_alpha"})
    assert "What should the subject be" in r_a2.json()["response"]
    assert r_a2.json()["in_conversation"] is True

    # User B asks for weather independently
    r_b2 = client.post("/api/assistant", json={"message": "weather in London", "session_id": "user_beta"})
    assert r_b2.json()["intent"] == "WEATHER"
    assert r_b2.json()["in_conversation"] is False


def test_rate_limiting(web_test_settings: Settings):
    """Test rate limiter blocks requests beyond limit."""
    # Settings with strict 2 requests per minute limit
    strict_settings = Settings(
        app_env=AppEnvironment.TESTING,
        web=WebSettings(rate_limit_per_minute=2),
    )
    app = create_app(settings=strict_settings)
    test_client = TestClient(app)

    r1 = test_client.post("/api/assistant", json={"message": "hello"})
    assert r1.status_code == 200

    r2 = test_client.post("/api/assistant", json={"message": "hello"})
    assert r2.status_code == 200

    # 3rd request must be blocked with HTTP 429
    r3 = test_client.post("/api/assistant", json={"message": "hello"})
    assert r3.status_code == 429
    assert "Too many requests" in r3.json()["detail"]
