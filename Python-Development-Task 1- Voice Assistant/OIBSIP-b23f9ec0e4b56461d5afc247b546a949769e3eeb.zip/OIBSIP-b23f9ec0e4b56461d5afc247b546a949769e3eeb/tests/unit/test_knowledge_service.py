"""Unit tests for knowledge service and QA providers."""

from unittest.mock import MagicMock

from voice_assistant.services.knowledge.client import (
    DuckDuckGoKnowledgeClient,
    WikipediaKnowledgeClient,
)
from voice_assistant.services.knowledge.models import KnowledgeAnswer
from voice_assistant.services.knowledge.provider import (
    CompositeKnowledgeProvider,
    KnowledgeService,
    LocalCuratedKnowledgeProvider,
    MockKnowledgeProvider,
)


def test_local_curated_knowledge():
    """Test instant answers from local curated knowledge base."""
    provider = LocalCuratedKnowledgeProvider()
    ans = provider.get_answer("who was Alan Turing")
    assert ans is not None
    assert "computer scientist" in ans.summary.lower()

    ans2 = provider.get_answer("what is the capital of Japan")
    assert ans2 is not None
    assert "tokyo" in ans2.summary.lower()


def test_composite_knowledge_fallback():
    """Test composite provider checking local first, then external clients."""
    mock_wiki = MagicMock(spec=WikipediaKnowledgeClient)
    mock_ddg = MagicMock(spec=DuckDuckGoKnowledgeClient)
    local = LocalCuratedKnowledgeProvider()

    composite = CompositeKnowledgeProvider(
        wiki_client=mock_wiki,
        ddg_client=mock_ddg,
        local_provider=local,
    )
    service = KnowledgeService(composite)

    # 1. Local hit
    res1 = service.answer_question("what is python")
    assert "programming language" in res1.lower()
    mock_wiki.search.assert_not_called()

    # 2. External Wikipedia hit
    mock_wiki.search.return_value = KnowledgeAnswer(
        query="Quantum Computing",
        summary="Quantum computing is a multidisciplinary field comprising aspects of computer science, physics, and mathematics.",
        source="Wikipedia",
    )
    res2 = service.answer_question("Quantum Computing")
    assert "quantum computing" in res2.lower()
    mock_wiki.search.assert_called_once_with("Quantum Computing")


def test_unknown_knowledge_fallback():
    """Test graceful message when knowledge query has no answers."""
    provider = MockKnowledgeProvider(predefined={})
    service = KnowledgeService(provider)
    res = service.answer_question("NonExistentHistoricalFigure12345")
    assert "couldn't find detailed information" in res.lower()
