"""Unit tests for custom commands repository, validation, and execution."""

from pathlib import Path

import pytest

from voice_assistant.config.constants import CustomActionType
from voice_assistant.errors.exceptions import SecurityValidationError
from voice_assistant.storage.custom_commands import (
    CustomCommandsStorage,
)


def test_custom_command_storage_lifecycle(temp_commands_file: Path):
    """Test full lifecycle of custom commands storage: add, save, reload, delete."""
    storage = CustomCommandsStorage(temp_commands_file)
    assert len(storage.list_commands()) == 0

    # Add open_url command
    cmd1 = storage.add_command(
        name="open github",
        action=CustomActionType.OPEN_URL,
        target="https://github.com",
    )
    assert cmd1.name == "open github"
    assert cmd1.action == CustomActionType.OPEN_URL

    # Add speak command
    cmd2 = storage.add_command(
        name="who is best",
        action=CustomActionType.SPEAK,
        target="You are the best!",
    )
    assert cmd2.name == "who is best"

    # Reload from disk to verify persistence
    reloaded_storage = CustomCommandsStorage(temp_commands_file)
    assert len(reloaded_storage.list_commands()) == 2
    assert reloaded_storage.get_command("open github") is not None
    assert reloaded_storage.get_command("who is best") is not None

    # Delete command
    deleted = reloaded_storage.delete_command("open github")
    assert deleted is True
    assert reloaded_storage.get_command("open github") is None
    assert len(reloaded_storage.list_commands()) == 1


def test_custom_command_security_rejections(temp_commands_file: Path):
    """Test security validation prevents unsafe targets or actions."""
    storage = CustomCommandsStorage(temp_commands_file)

    # Invalid URL scheme
    with pytest.raises(SecurityValidationError):
        storage.add_command(
            name="unsafe script",
            action=CustomActionType.OPEN_URL,
            target="javascript:alert(1)",
        )

    # Empty name
    with pytest.raises(SecurityValidationError):
        storage.add_command(
            name="",
            action=CustomActionType.SPEAK,
            target="Hello",
        )
