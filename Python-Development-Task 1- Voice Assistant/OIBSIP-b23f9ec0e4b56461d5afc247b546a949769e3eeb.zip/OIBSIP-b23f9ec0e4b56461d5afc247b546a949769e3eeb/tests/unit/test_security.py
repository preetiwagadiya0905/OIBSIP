"""Unit tests for security, secret masking, and input validation."""

import pytest

from voice_assistant.errors.exceptions import SecurityValidationError
from voice_assistant.security.secrets import redact_secrets, sanitize_dict
from voice_assistant.security.validators import (
    validate_custom_action,
    validate_email_address,
    validate_url,
)


def test_redact_secrets_in_strings():
    """Test masking of sensitive API keys and passwords."""
    raw = "Connecting with api_key='sk-1234567890abcdef' and password='SuperSecretPassword!'"
    redacted = redact_secrets(raw)
    assert "sk-1234567890abcdef" not in redacted
    assert "SuperSecretPassword!" not in redacted
    assert "***REDACTED***" in redacted


def test_sanitize_dictionary():
    """Test dict key sanitization."""
    data = {
        "user": "test_user",
        "api_key": "secret_api_key_xyz",
        "nested": {"password": "pass123", "normal": "ok"},
    }
    clean = sanitize_dict(data)
    assert clean["user"] == "test_user"
    assert clean["api_key"] == "***REDACTED***"
    assert clean["nested"]["password"] == "***REDACTED***"
    assert clean["nested"]["normal"] == "ok"


def test_validate_email_address_valid():
    """Test standard email address validation."""
    valid = validate_email_address("user.name+tag@example.com")
    assert valid == "user.name+tag@example.com"


@pytest.mark.parametrize("invalid_email", [
    "",
    "not-an-email",
    "@missinguser.com",
    "user@.com",
    "user@com",
])
def test_validate_email_address_invalid(invalid_email: str):
    """Test that invalid email formats raise SecurityValidationError."""
    with pytest.raises(SecurityValidationError):
        validate_email_address(invalid_email)


def test_validate_url_valid():
    """Test valid http/https URLs."""
    assert validate_url("https://github.com/test") == "https://github.com/test"
    assert validate_url("http://example.com:8080/path?q=1") == "http://example.com:8080/path?q=1"


@pytest.mark.parametrize("unsafe_url", [
    "",
    "javascript:alert(1)",
    "file:///etc/passwd",
    "data:text/html,<script>alert(1)</script>",
    "ftp://ftp.example.com",
    "http://",
])
def test_validate_url_unsafe_schemes(unsafe_url: str):
    """Test that unsafe schemes are rejected."""
    with pytest.raises(SecurityValidationError):
        validate_url(unsafe_url)


def test_validate_custom_action_allowlist():
    """Test allowed and disallowed custom actions."""
    # Allowed
    validate_custom_action("open_url", "https://github.com")
    validate_custom_action("speak", "Hello world")

    # Disallowed
    with pytest.raises(SecurityValidationError):
        validate_custom_action("execute_shell", "rm -rf /")

    with pytest.raises(SecurityValidationError):
        validate_custom_action("run_script", "python test.py")

    with pytest.raises(SecurityValidationError):
        validate_custom_action("open_url", "file:///c:/secret.txt")
