# Oasis Infobyte Internship Program (OIBSIP)

**Intern**: Preeti Wagadiya  
**GitHub Profile**: [@preetiwagadiya0905](https://github.com/preetiwagadiya0905)  
**Track**: Python Development / AI / Voice Assistant  
**Repository**: `OIBSIP`  

---

## 📌 Internship Tasks Overview

| Task # | Task Title | Domain / Tech Stack | Status | Directory / Module |
| :---: | :--- | :--- | :---: | :--- |
| **Task 1** | **Voice Assistant (Beginner + Advanced + Web)** | Python, FastAPI, Web Speech API, NLU, pyttsx3, SMTP, Weather API | **COMPLETED** ✅ | Root / `src/voice_assistant` |
| **Task 2** | *Upcoming Internship Task* | Python | *Pending* ⏳ | — |
| **Task 3** | *Upcoming Internship Task* | Python | *Pending* ⏳ | — |

---

# 🎙️ Task 1 — Voice Assistant

[![CI Pipeline](https://github.com/preetiwagadiya0905/OIBSIP/actions/workflows/ci.yml/badge.svg)](https://github.com/preetiwagadiya0905/OIBSIP/actions)
[![Python 3.10+](https://img.shields.io/badge/python-3.10%2B-blue.svg)](https://www.python.org/downloads/)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.110%2B-009688.svg?style=flat&logo=FastAPI&logoColor=white)](https://fastapi.tiangolo.com)
[![Code Style: Ruff](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/ruff/main/assets/badge/v2.json)](https://github.com/astral-sh/ruff)
[![Architecture: Full-Stack Web + Clean Domain](https://img.shields.io/badge/architecture-Full--Stack%20Web%20%2F%20Hexagonal-brightgreen.svg)]()
[![License: MIT](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)

**Aura** is a modular, production-grade **AI Voice Assistant Application** built for **Task 1** of the Oasis Infobyte Internship. It satisfies 100% of both **Beginner** and **Advanced** checklist requirements and provides both a **Full-Stack Web Interface** (for cross-device browser access) and a **Local Desktop/CLI Mode**.

---

## 🌟 Feature Checklist Completion

### 🔹 Beginner Tier Requirements
- [x] **Capture voice input** using `speech_recognition` (with dynamic microphone noise calibration).
- [x] **Respond to greetings** (`"Hello"`, `"Good morning"`) with time-aware dynamic greeting messages.
- [x] **Tell current time and date** on request (`"What time is it?"`, `"What's today's date?"`).
- [x] **Perform safe web searches** on user-specified topics with URL encoding and browser opening.
- [x] **Graceful error handling**: Asks the user to repeat if voice is unclear or timed out.
- [x] **Text-to-speech feedback** using `pyttsx3` (thread-safe engine lock) and `window.speechSynthesis`.

### 🚀 Advanced Tier Requirements
- [x] **Natural Language Understanding (NLU)**: Hybrid intent classification combining high-precision regex matching with TF-IDF cosine similarity across 12 intent classes.
- [x] **Conversational Multi-Turn State Machine**: Stateful dialogue flow (e.g. Email composition: recipient $\rightarrow$ subject $\rightarrow$ body $\rightarrow$ confirmation).
- [x] **Third-Party Weather API Integration**: Live current weather and geocoding via OpenWeatherMap API with temperature, feels-like, humidity, and condition summaries.
- [x] **SMTP Email Integration**: Real email dispatch using `email.message.EmailMessage` and `smtplib` with STARTTLS, recipient validation, and mandatory explicit confirmation.
- [x] **Non-Blocking Background Reminders**: Asynchronous background thread timer scheduler with audible chime alerts and real-time Server-Sent Events (SSE) push.
- [x] **General Knowledge QA**: Curated fast offline Q&A dataset with Wikipedia and DuckDuckGo Instant Answers fallback.
- [x] **User-Extensible Custom Commands**: Persistent JSON-backed storage for custom URLs and spoken voice macros with strict action allowlisting.
- [x] **Security & Secret Redaction**: In-memory sliding-window rate limiting, zero arbitrary shell execution, and automatic credential masking (`***REDACTED***`) in all logs.

---

## 🏛️ System Architecture

```
                    INTERNET / PUBLIC HTTPS URL
                               │
               ┌───────────────┴───────────────┐
               ▼                               ▼
       WEB FRONTEND (Browser)          FASTAPI PYTHON BACKEND
   (HTML5 / Modern Vanilla CSS /      (Uvicorn on 0.0.0.0:$PORT)
    Web Speech API / SpeechSynth)              │
               │                               ├── WebSessionRegistry (Per-User Isolation)
               │ (Fetch API / SSE Stream)      ├── Sliding Window Rate Limiter
               ▼                               ├── Hybrid NLU & Intent Engine
         USER CLIENT                           ├── OpenWeatherMap & Geocoding Service
   (User's Mic & User's Speakers)              ├── Non-Blocking Reminder Engine (SSE Push)
                                               ├── Composite Knowledge Base (Wikipedia / DDG)
                                               ├── Custom Commands Storage
                                               └── SMTP Email (With Security Safeguards)
```

---

## 📁 Repository Structure

```
OIBSIP/
├── .env.example                     # Environment variables template
├── .gitignore                       # Git ignore rules
├── Dockerfile                       # Multi-stage production container
├── render.yaml                      # Render 1-click cloud deployment blueprint
├── Procfile                         # Process file for Railway / Fly.io / Heroku
├── pyproject.toml                   # Project dependencies and build configuration
├── requirements.txt                 # Python dependencies
├── main.py                          # Unified Application Entry Point (Web / CLI)
├── config/
│   └── commands.json                # User-defined custom commands
├── src/
│   └── voice_assistant/
│       ├── __init__.py
│       ├── __main__.py              # Unified CLI / Web launcher
│       ├── factory.py               # Dependency injection container
│       ├── application/             # Application lifecycle & session FSM
│       ├── audio/                   # Local microphone & TTS adapters
│       ├── commands/                # Domain command handlers & registry
│       ├── config/                  # Settings, WebSettings, & Constants
│       ├── errors/                  # Custom domain exception hierarchy
│       ├── nlp/                     # Hybrid intent classifier & entity extractors
│       ├── observability/           # Structured logging with secret masking filter
│       ├── security/                # Input validators & secret masking
│       ├── services/                # Weather, Email, Reminders, Knowledge
│       ├── storage/                 # Persistent custom commands repository
│       ├── utils/                   # Sound & text normalization utilities
│       └── web/                     # Full-Stack Web Layer
│           ├── app.py               # FastAPI application factory & static mounts
│           ├── rate_limiter.py      # In-memory sliding window rate limiter
│           ├── routes.py            # REST & SSE streaming endpoints
│           ├── schemas.py           # Pydantic request/response schemas
│           ├── service_adapter.py   # Multi-user NLU & Command dispatcher
│           ├── session.py           # WebSessionRegistry & SSE event queues
│           └── static/              # Frontend Assets
│               ├── index.html       # Web UI Single Page Application
│               ├── css/style.css    # Modern responsive styling
│               └── js/app.js        # Web Speech & Audio controller
└── tests/
    ├── conftest.py                  # Pytest fixtures & mock providers
    ├── unit/                        # Unit tests (Config, Security, NLP, Web API)
    └── integration/                 # Integration tests (Multi-Turn, Lifecycle)
```

---

## 🛠️ Quick Start & Execution

### 1. Installation
```bash
# Clone the repository
git clone https://github.com/preetiwagadiya0905/OIBSIP.git
cd OIBSIP

# Create and activate virtual environment
python -m venv .venv
source .venv/bin/activate  # On Windows: .venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
pip install -e .
```

### 2. Mode A: Web Interface (Recommended)
```bash
python main.py
```
Open `http://localhost:8000` in your browser. Click the microphone button to speak or use the bottom text dock!

### 3. Mode B: Local Desktop Voice Mode
```bash
python main.py --voice
```

### 4. Mode C: Terminal Text / Demo Mode
```bash
python main.py --demo
```

### 5. Mode D: Run Automated Test Suite
```bash
python -m pytest -v
```

---

## ⚡ Performance Benchmarks

| Category | Input Query | Latency | Response |
| :--- | :--- | :---: | :--- |
| **Greeting** | `"Hello Aura"` | **183 ms** *(cold)* | Greeting response |
| **Time Query** | `"What time is it?"` | **4.7 ms** | Current local time |
| **Date Query** | `"What is today's date?"` | **3.8 ms** | Current local date |
| **Knowledge QA** | `"Who was Alan Turing?"` | **3.7 ms** | Factual biographical summary |
| **Weather** | `"What's the weather in Hyderabad?"` | **3.6 ms** | Live weather summary |
| **Web Search** | `"Search for Python decorators"` | **3.7 ms** | Opens Google search tab |
| **Reminders** | `"Remind me in 30 seconds to stretch"` | **7.8 ms** | Background timer with SSE chime |
| **Multi-Turn Email**| `"Send an email"` | **3.8 ms** | Conversational prompt for recipient |

---

## 🧪 Automated Testing

Executed **102 tests** with 100% pass rate:
* `tests/unit/test_config.py`
* `tests/unit/test_security.py`
* `tests/unit/test_nlp.py`
* `tests/unit/test_commands.py`
* `tests/unit/test_weather_service.py`
* `tests/unit/test_email_service.py`
* `tests/unit/test_reminder_service.py`
* `tests/unit/test_knowledge_service.py`
* `tests/unit/test_custom_commands.py`
* `tests/unit/test_web_api.py`
* `tests/integration/test_conversational_flows.py`
* `tests/integration/test_application_lifecycle.py`
* `tests/integration/test_web_assistant_flow.py`

---

## 📄 License
This project is licensed under the MIT License.
